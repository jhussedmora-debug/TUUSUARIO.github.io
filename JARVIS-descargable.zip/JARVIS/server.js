#!/usr/bin/env node
'use strict';
/*
 * JARVIS · servidor local (reconstruido para encajar con public/app.js)
 * Sin dependencias. Hace tres cosas:
 *   1. Sirve la app (carpeta public/).
 *   2. Guarda tus claves de API (archivo .env) y las usa para hablar con Anthropic (Claude), OpenAI (ChatGPT) y xAI (Grok).
 *   3. Nunca envía una clave al navegador.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

if (parseInt(process.versions.node, 10) < 18) {
  console.error('JARVIS necesita Node.js 18 o superior. Tienes ' + process.versions.node + '.');
  process.exit(1);
}

const ROOT = __dirname;
const PUB = path.join(ROOT, 'public');

function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    if (/^\s*#/.test(line)) continue;
    const m = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (!m) continue;
    let v = m[2];
    if (/^(".*"|'.*')$/.test(v)) v = v.slice(1, -1);
    if (!(m[1] in process.env)) process.env[m[1]] = v;
  }
}
loadEnv(path.join(ROOT, '.env'));
const env = process.env;

function clampInt(v, def, lo, hi) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : def;
}
const PORT = clampInt(env.PORT, 8787, 1, 65535);
const HOST = (env.HOST || '127.0.0.1').trim();
const PIN = (env.ACCESS_PIN || '').trim();
const MAX_OUT = clampInt(env.MAX_OUTPUT_TOKENS, 4096, 256, 32000);
const DAILY = clampInt(env.MAX_CALLS_PER_DAY, 300, 1, 100000);
const TIMEOUT_MS = clampInt(env.REQUEST_TIMEOUT_MS, 120000, 1000, 600000);
const BODY_LIMIT = 12 * 1024 * 1024;
const isLoop = (h) => ['127.0.0.1', 'localhost', '::1'].includes(h);

if (!isLoop(HOST) && PIN.length < 4) {
  console.error('\nHOST=' + HOST + ' abre JARVIS a toda tu red, y tus claves de API pagarían las peticiones de cualquiera.');
  console.error('Define ACCESS_PIN en el archivo .env con al menos 4 caracteres, o quita la línea HOST.\n');
  process.exit(1);
}

/* ---------- proveedores (los ids son los que usa app.js) ---------- */
const PROVIDERS = {
  claude: {
    label: 'Claude (Anthropic)', keyVar: 'ANTHROPIC_API_KEY', modelVar: 'ANTHROPIC_MODEL',
    base: (env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com').replace(/\/+$/, ''), kind: 'anthropic', keep: /./,
  },
  openai: {
    label: 'ChatGPT (OpenAI)', keyVar: 'OPENAI_API_KEY', modelVar: 'OPENAI_MODEL',
    base: (env.OPENAI_BASE_URL || 'https://api.openai.com').replace(/\/+$/, ''), kind: 'openai', keep: /^(gpt|o\d|chatgpt)/i,
  },
  grok: {
    label: 'Grok (xAI)', keyVar: 'XAI_API_KEY', modelVar: 'XAI_MODEL',
    base: (env.XAI_BASE_URL || 'https://api.x.ai').replace(/\/+$/, ''), kind: 'openai', keep: /^grok/i,
  },
};
const NOT_CHAT = /embed|whisper|tts|dall|image|imagine|audio|realtime|transcribe|moderation|search|computer-use|davinci|babbage|instruct$/i;
const keyOf = (id) => (env[PROVIDERS[id].keyVar] || '').trim();
const configured = (id) => keyOf(id).length > 0;
const defModel = (id) => (env[PROVIDERS[id].modelVar] || '').trim();

/* ---------- límite diario de llamadas ---------- */
let day = today(), calls = 0;
function today() { return new Date().toLocaleDateString('en-CA'); }
function takeCall() {
  if (today() !== day) { day = today(); calls = 0; }
  if (calls >= DAILY) return false;
  calls++;
  return true;
}

/* ---------- utilidades HTTP ---------- */
const SEC = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY' };
const CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; font-src 'self'; img-src 'self' data: blob:; " +
  "media-src 'self' blob:; connect-src 'self'; worker-src 'self'; manifest-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'";

function send(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(body) }, SEC));
  res.end(body);
}
const fail = (res, status, code, message) => send(res, status, { error: { code, message } });

function hostOk(req) {
  if (!isLoop(HOST)) return true; // modo red local: protege el PIN
  const h = String(req.headers.host || '').toLowerCase().replace(/:\d+$/, '').replace(/^\[|\]$/g, '');
  return isLoop(h);
}
function originOk(req) {
  const o = req.headers.origin;
  if (!o) return true;
  try { return new URL(o).host.toLowerCase() === String(req.headers.host || '').toLowerCase(); } catch (e) { return false; }
}

/* PIN con freno a los intentos fallidos */
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();
const tries = new Map(); // ip -> {n, until}
function pinState(req) {
  if (!PIN) return { ok: true };
  const ip = req.socket.remoteAddress || '?';
  const t = tries.get(ip) || { n: 0, until: 0 };
  if (t.until > Date.now()) return { ok: false, locked: true };
  const given = String(req.headers['x-jarvis-pin'] || '');
  if (given && crypto.timingSafeEqual(sha(given), sha(PIN))) { tries.delete(ip); return { ok: true }; }
  if (given) {
    t.n++;
    if (t.n >= 5) { t.n = 0; t.until = Date.now() + 60000; }
    tries.set(ip, t);
  }
  return { ok: false, locked: t.until > Date.now() };
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0, over = false; const chunks = [];
    req.on('data', (c) => {
      if (over) return; // se descarta el resto para poder contestar 413
      size += c.length;
      if (size > BODY_LIMIT) { over = true; chunks.length = 0; reject(Object.assign(new Error('grande'), { status: 413 })); return; }
      chunks.push(c);
    });
    req.on('end', () => { if (!over) resolve(Buffer.concat(chunks).toString('utf8')); });
    req.on('error', (e) => { if (!over) reject(e); });
  });
}
function scrub(text) {
  let t = String(text == null ? '' : text);
  for (const id of Object.keys(PROVIDERS)) { const k = keyOf(id); if (k.length > 6) t = t.split(k).join('[clave]'); }
  return t.slice(0, 500);
}

/* ---------- llamadas a los proveedores ---------- */
function authHeaders(id) {
  return PROVIDERS[id].kind === 'anthropic'
    ? { 'x-api-key': keyOf(id), 'anthropic-version': '2023-06-01' }
    : { Authorization: 'Bearer ' + keyOf(id) };
}
function mapUpstream(id, status, json, raw) {
  let msg = '', ecode = '';
  if (json && json.error) {
    if (typeof json.error === 'string') msg = json.error;
    else { msg = json.error.message || json.error.type || ''; ecode = String(json.error.code || json.error.type || ''); }
  }
  if (!msg) msg = String(raw || '').slice(0, 200);
  msg = scrub(msg);
  const label = PROVIDERS[id].label, all = msg + ' ' + ecode;
  if (status === 401 || status === 403) return { http: 502, code: 'auth', message: label + ' rechazó la clave de API (' + status + '). Revisa la clave con «node setup.js». ' + msg };
  if (status === 402 || /insufficient_quota|credit balance|billing|exceeded your current quota|out of credits/i.test(all)) return { http: 502, code: 'quota', message: label + ' indica que no queda saldo o cuota en tu cuenta de API. ' + msg };
  if (status === 429) return { http: 429, code: 'rate_limited', message: label + ' limitó las peticiones (429). Espera un momento. ' + msg };
  if (status === 404 || /model_not_found|model.*(not found|does not exist|not supported|deprecated)/i.test(all)) return { http: 502, code: 'bad_model', message: label + ' no reconoce ese modelo. Elige otro en Ajustes con «Cargar modelos». ' + msg };
  return { http: 502, code: 'upstream_error', message: label + ' respondió con un error (' + status + '). ' + msg };
}
async function callUpstream(id, urlPath, init) {
  const p = PROVIDERS[id];
  let r;
  try {
    r = await fetch(p.base + urlPath, Object.assign({ signal: AbortSignal.timeout(TIMEOUT_MS) }, init));
  } catch (e) {
    const timeout = e && (e.name === 'TimeoutError' || e.name === 'AbortError');
    throw timeout
      ? { http: 504, code: 'timeout', message: p.label + ' tardó más de ' + Math.round(TIMEOUT_MS / 1000) + ' s en responder.' }
      : { http: 502, code: 'network', message: 'No se pudo conectar con ' + p.label + '. Comprueba tu conexión a Internet.' };
  }
  const raw = await r.text();
  let json = null;
  try { json = JSON.parse(raw); } catch (e) { /* no era JSON */ }
  if (!r.ok) throw mapUpstream(id, r.status, json, raw);
  if (!json) throw { http: 502, code: 'upstream_error', message: p.label + ' devolvió una respuesta que no es JSON.' };
  return json;
}

async function listModels(id) {
  const p = PROVIDERS[id];
  const j = await callUpstream(id, '/v1/models' + (p.kind === 'anthropic' ? '?limit=100' : ''), { headers: authHeaders(id) });
  const rows = Array.isArray(j.data) ? j.data : [];
  let ids = rows.map((m) => String((m && m.id) || '')).filter((m) => m && p.keep.test(m) && !NOT_CHAT.test(m));
  if (p.kind !== 'anthropic') ids.sort().reverse();
  return ids.slice(0, 80);
}

const JSON_SUFFIX = '\n\nResponde únicamente con un valor JSON válido. Sin texto antes ni después y sin bloques de código.';
function validateChat(b) {
  if (!b || typeof b !== 'object') return 'Petición vacía.';
  if (!PROVIDERS[b.provider]) return 'Proveedor desconocido.';
  if (b.model != null && b.model !== '' && !/^[\w.:\-\/]{1,100}$/.test(String(b.model))) return 'Nombre de modelo no válido.';
  if (!Array.isArray(b.messages) || b.messages.length < 1 || b.messages.length > 40) return 'Mensajes no válidos.';
  for (const m of b.messages) {
    if (!m || (m.role !== 'user' && m.role !== 'assistant') || typeof m.content !== 'string' || !m.content.trim() || m.content.length > 250000) return 'Mensajes no válidos.';
  }
  if (b.messages[b.messages.length - 1].role !== 'user') return 'El último mensaje debe ser del usuario.';
  if (b.images != null) {
    if (!Array.isArray(b.images) || b.images.length > 4) return 'Imágenes no válidas.';
    for (const im of b.images) {
      if (!im || !/^image\/(jpeg|png|webp|gif)$/.test(im.mime) || typeof im.data !== 'string' || im.data.length > 8 * 1024 * 1024 || !/^[A-Za-z0-9+/=]+$/.test(im.data)) return 'Imagen no válida.';
    }
  }
  return '';
}

async function chat(b) {
  const id = b.provider, p = PROVIDERS[id];
  if (!configured(id)) throw { http: 400, code: 'not_configured', message: 'No hay clave de API para ' + p.label + ' en el archivo .env.' };
  const model = String(b.model || defModel(id) || '').trim();
  if (!model) throw { http: 400, code: 'no_model', message: 'Elige un modelo de ' + p.label + ' en Ajustes.' };
  const msgs = b.messages.map((m) => ({ role: m.role, content: m.content }));
  if (b.json) msgs[msgs.length - 1].content += JSON_SUFFIX;
  const images = Array.isArray(b.images) ? b.images : [];
  let body, urlPath;

  if (p.kind === 'anthropic') {
    urlPath = '/v1/messages';
    if (images.length) {
      const last = msgs[msgs.length - 1];
      last.content = images.map((im) => ({ type: 'image', source: { type: 'base64', media_type: im.mime, data: im.data } })).concat([{ type: 'text', text: last.content }]);
    }
    body = { model, max_tokens: MAX_OUT, messages: msgs };
  } else {
    urlPath = '/v1/chat/completions';
    if (images.length) {
      const last = msgs[msgs.length - 1];
      last.content = [{ type: 'text', text: last.content }].concat(images.map((im) => ({ type: 'image_url', image_url: { url: 'data:' + im.mime + ';base64,' + im.data } })));
    }
    body = { model, messages: msgs };
  }

  if (!takeCall()) throw { http: 429, code: 'daily_limit', message: 'Alcanzaste el límite diario de ' + DAILY + ' llamadas que fijaste en MAX_CALLS_PER_DAY. Se reinicia mañana.' };
  const j = await callUpstream(id, urlPath, { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, authHeaders(id)), body: JSON.stringify(body) });

  let text = '', truncated = false;
  if (p.kind === 'anthropic') {
    text = (Array.isArray(j.content) ? j.content : []).filter((x) => x && x.type === 'text').map((x) => x.text).join('');
    truncated = j.stop_reason === 'max_tokens';
  } else {
    const c = j.choices && j.choices[0];
    const content = c && c.message && c.message.content;
    text = Array.isArray(content) ? content.map((x) => (x && x.text) || '').join('') : String(content || '');
    truncated = !!(c && c.finish_reason === 'length');
  }
  if (!text.trim()) throw { http: 502, code: 'empty', message: p.label + ' no devolvió texto.' };
  return { text, truncated, model, provider: id };
}

/* ---------- rutas ---------- */
async function handleApi(req, res, url) {
  if (!hostOk(req)) return fail(res, 403, 'forbidden', 'Host no permitido.');
  if (!originOk(req)) return fail(res, 403, 'forbidden', 'Origen no permitido.');
  const pin = pinState(req);

  if (req.method === 'GET' && url.pathname === '/api/status') {
    if (!pin.ok) return send(res, 200, { pinRequired: true, authorized: false, locked: !!pin.locked });
    const providers = {};
    for (const id of Object.keys(PROVIDERS)) providers[id] = { configured: configured(id), model: defModel(id) };
    return send(res, 200, { pinRequired: !!PIN, authorized: true, providers, calls, dailyLimit: DAILY });
  }
  if (!pin.ok) return fail(res, pin.locked ? 429 : 401, pin.locked ? 'locked' : 'unauthorized', pin.locked ? 'Demasiados intentos con el PIN. Espera un minuto.' : 'Falta el PIN o no es correcto.');

  if (req.method === 'GET' && url.pathname === '/api/models') {
    const id = url.searchParams.get('provider');
    if (!PROVIDERS[id]) return fail(res, 400, 'bad_request', 'Proveedor desconocido.');
    if (!configured(id)) return fail(res, 400, 'not_configured', 'No hay clave de API para ' + PROVIDERS[id].label + '.');
    return send(res, 200, { models: await listModels(id) });
  }
  if (req.method === 'POST' && url.pathname === '/api/chat') {
    if (!/^application\/json\b/i.test(req.headers['content-type'] || '')) return fail(res, 415, 'bad_request', 'Se esperaba application/json.');
    let b;
    try { b = JSON.parse(await readBody(req)); } catch (e) {
      if (e && e.status === 413) {
        res.setHeader('Connection', 'close');
        res.on('finish', () => { setTimeout(() => req.destroy(), 3000).unref(); });
        return fail(res, 413, 'bad_request', 'La petición es demasiado grande.');
      }
      return fail(res, 400, 'bad_request', 'JSON no válido.');
    }
    const problem = validateChat(b);
    if (problem) return fail(res, 400, 'bad_request', problem);
    const r = await chat(b);
    console.log(new Date().toLocaleTimeString() + '  ' + r.provider + ' · ' + r.model + ' · ok (' + calls + '/' + DAILY + ' hoy)');
    return send(res, 200, { text: r.text, truncated: r.truncated, model: r.model, provider: r.provider });
  }
  return fail(res, 404, 'not_found', 'Ruta desconocida.');
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.ttf': 'font/ttf',
};
function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, SEC); return res.end(); }
  if (!hostOk(req)) { res.writeHead(403, SEC); return res.end('Host no permitido'); }
  let p;
  try { p = decodeURIComponent(url.pathname); } catch (e) { res.writeHead(400, SEC); return res.end(); }
  if (p.includes('\0')) { res.writeHead(400, SEC); return res.end(); }
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(PUB, p));
  if (file !== PUB && !file.startsWith(PUB + path.sep)) { res.writeHead(403, SEC); return res.end('Prohibido'); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, SEC); return res.end('No encontrado'); }
    const ext = path.extname(file).toLowerCase();
    const headers = Object.assign({ 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'no-cache' }, SEC);
    if (ext === '.html') headers['Content-Security-Policy'] = CSP;
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

const server = http.createServer((req, res) => {
  let url;
  try { url = new URL(req.url, 'http://localhost'); } catch (e) { res.writeHead(400, SEC); return res.end(); }
  if (url.pathname.startsWith('/api/')) {
    handleApi(req, res, url).catch((e) => {
      if (e && e.code && e.message && e.http) return fail(res, e.http, e.code, e.message);
      console.error('Error interno:', scrub(e && e.stack ? e.stack : e));
      fail(res, 500, 'upstream_error', 'Error interno del servidor de JARVIS.');
    });
  } else serveStatic(req, res, url);
});
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') console.error('\nEl puerto ' + PORT + ' ya está en uso. Cierra la otra copia de JARVIS o cambia PORT en .env.\n');
  else console.error('\nNo se pudo iniciar el servidor: ' + e.message + '\n');
  process.exit(1);
});
server.listen(PORT, HOST, () => {
  const ids = Object.keys(PROVIDERS).filter(configured);
  console.log('\n  JARVIS está en marcha: http://localhost:' + PORT);
  console.log('  Escuchando en ' + HOST + (PIN ? ' (protegido con PIN)' : ' (solo este dispositivo)'));
  console.log('  IA conectada: ' + (ids.length ? ids.map((i) => PROVIDERS[i].label).join(', ') : 'ninguna. Sin claves, JARVIS funciona en modo local con plantillas.'));
  console.log('  Límite diario de llamadas: ' + DAILY + '\n  Para parar: Ctrl+C\n');
});
