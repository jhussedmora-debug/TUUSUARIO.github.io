#!/usr/bin/env node
/* Asistente de configuración: guarda tus claves en .env (solo legible por ti).
 * Las claves se escriben en este archivo y en ningún otro sitio. */
'use strict';
const fs = require('fs');
const path = require('path');
const readline = require('readline/promises');

const FILE = path.join(__dirname, '.env');
const FIELDS = [
  ['ANTHROPIC_API_KEY', 'Clave de Claude (Anthropic), empieza por sk-ant-'],
  ['OPENAI_API_KEY', 'Clave de ChatGPT (OpenAI), empieza por sk-'],
  ['XAI_API_KEY', 'Clave de Grok (xAI), empieza por xai-'],
  ['ACCESS_PIN', 'PIN para abrir JARVIS desde otros dispositivos de tu red (opcional)']
];

function parse(txt) {
  const o = {};
  for (const l of txt.split(/\r?\n/)) {
    const m = l.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !l.trim().startsWith('#')) o[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
  return o;
}

(async () => {
  let current = {};
  let text = '';
  try { text = fs.readFileSync(FILE, 'utf8'); current = parse(text); } catch (e) { /* aún no existe */ }
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  console.log('\nJARVIS · configuración');
  console.log('Pulsa Enter para dejar un campo como está. Escribe - para borrarlo.');
  console.log('Cada proveedor de API cobra por uso a tu cuenta. Puedes dejar vacíos los que no uses.\n');
  const next = Object.assign({}, current);
  for (const [k, label] of FIELDS) {
    const has = current[k] ? ' [ya configurada]' : '';
    const ans = (await rl.question(label + has + ': ')).trim();
    if (ans === '-') delete next[k];
    else if (ans) next[k] = ans;
  }
  rl.close();
  if (next.ACCESS_PIN && next.ACCESS_PIN.length < 4) { console.error('\nEl PIN debe tener al menos 4 caracteres. No se guardó nada.'); process.exit(1); }
  const lines = text ? text.split(/\r?\n/) : ['# Configuración de JARVIS. No compartas este archivo.'];
  const seen = new Set();
  const out = lines.map(l => {
    const m = l.match(/^\s*([A-Za-z0-9_]+)\s*=/);
    if (m && !l.trim().startsWith('#') && FIELDS.some(f => f[0] === m[1])) {
      seen.add(m[1]);
      return next[m[1]] ? m[1] + '=' + next[m[1]] : null;
    }
    return l;
  }).filter(l => l !== null);
  for (const [k] of FIELDS) if (!seen.has(k) && next[k]) out.push(k + '=' + next[k]);
  fs.writeFileSync(FILE, out.join('\n').replace(/\n+$/, '') + '\n', { mode: 0o600 });
  try { fs.chmodSync(FILE, 0o600); } catch (e) { /* Windows */ }
  const n = ['ANTHROPIC_API_KEY', 'OPENAI_API_KEY', 'XAI_API_KEY'].filter(k => next[k]).length;
  console.log('\nGuardado en ' + FILE + ' (' + n + ' proveedor(es) con clave).');
  console.log('Arranca JARVIS con:  node server.js\n');
})().catch(e => { console.error(e.message); process.exit(1); });
