(()=>{
'use strict';
/* ============================================================
   JARVIS · módulos
   UI · Store (proyectos) · Script (guiones) · Render (escenas)
   Audio (música/efectos) · Export (grabación y verificación)
   Chat (órdenes) · Publish (metadatos) · Errors
   ============================================================ */

/* ---------- utilidades ---------- */
const $=(s,el=document)=>el.querySelector(s), $$=(s,el=document)=>[...el.querySelectorAll(s)];
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>Math.random().toString(36).slice(2,9)+Date.now().toString(36).slice(-3);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const fmtT=s=>{s=Math.max(0,s||0);return Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0')};
const fmtSize=b=>b>=1e6?(b/1e6).toFixed(1)+' MB':Math.max(1,Math.round(b/1e3))+' KB';
const slug=s=>String(s||'video').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,40)||'video';
const clone=o=>JSON.parse(JSON.stringify(o));
const ease=t=>1-Math.pow(1-t,3);
const LANGN={es:'español',pt:'portugués',en:'inglés'};
const NOSE=new Set(['not_granted','sampling_disabled','not_declared','capability_disabled','capability_removed']);

/* ---------- registro de errores ---------- */
const ErrLog=[];
function logError(area,e){
  const msg=(e&&(e.message||e.code))||String(e);
  ErrLog.unshift({t:Date.now(),area,msg:String(msg).slice(0,300)});
  if(ErrLog.length>40)ErrLog.pop();
  renderErrors();
  return msg;
}
function toast(msg,ms=3200){
  const el=$('#toast'); el.textContent=msg; el.hidden=false;
  clearTimeout(toast.t); toast.t=setTimeout(()=>{el.hidden=true},ms);
}

/* ---------- perfiles ---------- */
const PROFILES0={
  gaming:{key:'gaming',name:'Videojuegos',style:'Neón, cortes rápidos, energía alta',narrator:'masculina',seconds:30,mood:'energetic',pal:['#05030f','#4c1d95','#22d3ee','#f472b6'],bg:'grid',audience:'Jugadores de 13 a 30 años',topic:'Curiosidades de videojuegos'},
  asmr:{key:'asmr',name:'ASMR',style:'Suave, lento, colores fríos y desenfoque',narrator:'sin voz',seconds:45,mood:'calm',pal:['#060811','#1e3a5f','#7dd3fc','#c4b5fd'],bg:'bokeh',audience:'Personas que buscan relajarse o dormir',topic:'Ambiente relajante para dormir'},
  autos:{key:'autos',name:'Restauración de coches',style:'Metal, taller, tonos cálidos y naranja',narrator:'masculina',seconds:40,mood:'industrial',pal:['#0b0907','#7c2d12','#f59e0b','#94a3b8'],bg:'brushed',audience:'Aficionados al motor y al bricolaje',topic:'Restauración de un coche clásico'},
  edu:{key:'edu',name:'Educación',style:'Limpio, azul, tipografía clara',narrator:'femenina',seconds:30,mood:'bright',pal:['#040b1a','#1d4ed8','#22d3ee','#fde68a'],bg:'hud',audience:'Estudiantes y curiosos',topic:'Un tema educativo'}
};

/* ---------- estado ---------- */
const S={
  view:'inicio',projects:[],cur:null,busy:false,rendering:false,abort:false,
  settings:{useClaude:true,autoRender:true,prefs:[],defaultAspect:'9:16',provider:'auto',models:{claude:'',openai:'',grok:''},profiles:clone(PROFILES0)},
  pipe:{},result:null,chat:[],turns:[],storage:'Navegador (local)',errors:ErrLog
};
const CAP={sample:null,downloads:null,db:null,perm:null,images:false,blocked:false,ready:false};
const MEDIA={img:{},voice:null,voiceName:'',music:null,musicName:''};
const getP=()=>S.cur;
/* ============================================================
   AI · proveedores (modo app: servidor local con las claves en .env)
   ============================================================ */
const IS_APP=!window.claude;
const AI={
  status:null,pin:'',last:null,models:{},
  order:['claude','openai','grok'],
  label:{claude:'Claude',openai:'ChatGPT',grok:'Grok'},
  info(id){return this.status&&this.status.providers&&this.status.providers[id]||null;},
  configured(){return this.order.filter(id=>{const i=this.info(id);return i&&i.configured;});},
  usable(id){const i=this.info(id);return !!(i&&i.configured&&(S.settings.models[id]||i.model));},
  chosen(){const p=S.settings.provider;return this.order.filter(id=>(p==='auto'||p===id)&&this.usable(id));},
  async api(path,o={}){
    const h={'content-type':'application/json'};if(this.pin)h['x-jarvis-pin']=this.pin;
    let r;
    try{r=await fetch(path,{method:o.method||'GET',headers:h,body:o.body?JSON.stringify(o.body):undefined,signal:o.signal});}
    catch(e){if(e&&e.name==='AbortError')throw{code:'cancelled',message:'Cancelado'};throw{code:'no_server',message:'No se pudo hablar con el servidor local de JARVIS.'};}
    let j=null;try{j=await r.json();}catch(e){}
    if(!r.ok){const er=(j&&j.error)||{};throw{code:er.code||'upstream_error',message:er.message||('Error '+r.status),status:r.status};}
    return j;
  },
  async loadStatus(){try{this.status=await this.api('/api/status');}catch(e){this.status=null;}},
  async loadModels(id){const j=await this.api('/api/models?provider='+encodeURIComponent(id));this.models[id]=j.models||[];return this.models[id];}
};
function aiName(){
  if(!IS_APP)return 'Claude';
  const c=AI.chosen();
  if(AI.last&&c.includes(AI.last))return AI.label[AI.last];
  return c.length===1?AI.label[c[0]]:'IA';
}
const claudeOK=()=>!!(CAP.sample&&S.settings.useClaude&&!CAP.blocked&&(!IS_APP||AI.chosen().length));
const b64=async blob=>{const buf=new Uint8Array(await blob.arrayBuffer());let s='';for(let i=0;i<buf.length;i+=32768)s+=String.fromCharCode.apply(null,buf.subarray(i,i+32768));return btoa(s);};
function parseJsonLoose(t){
  try{return JSON.parse(t);}catch(e){}
  const f=t.match(/```(?:json)?\s*([\s\S]*?)```/i);if(f){try{return JSON.parse(f[1]);}catch(e){}}
  const a=t.search(/[\[{]/),z=Math.max(t.lastIndexOf('}'),t.lastIndexOf(']'));
  if(a>=0&&z>a){try{return JSON.parse(t.slice(a,z+1));}catch(e){}}
  throw{code:'invalid_json',message:'La IA no devolvió JSON válido',text:t};
}
const FALLBACK_CODES=['auth','quota','rate_limited','upstream_error','bad_model','no_model','not_configured','network','timeout','empty'];
function makeSample(){
  const call=async(input,opts,asJson)=>{
    opts=opts||{};
    const messages=typeof input==='string'?[{role:'user',content:input}]:input.map(m=>({role:m.role,content:m.content}));
    const images=[];
    for(const b of [].concat(opts.images||[]).slice(0,4))images.push({mime:b.type||'image/jpeg',data:await b64(b)});
    const list=AI.chosen();
    if(!list.length)throw{code:'not_configured',message:'Ningún proveedor de IA está listo'};
    let lastErr=null;
    for(let k=0;k<list.length;k++){
      const id=list[k];
      try{
        const j=await AI.api('/api/chat',{method:'POST',signal:opts.signal,body:{provider:id,model:S.settings.models[id]||undefined,messages,images,json:!!asJson}});
        AI.last=id;renderTop();
        if(opts.onText)opts.onText({text:j.text,delta:j.text});
        return{text:j.text,truncated:!!j.truncated};
      }catch(e){
        lastErr=e;
        if(k<list.length-1&&FALLBACK_CODES.includes(e.code)){toast(AI.label[id]+' falló ('+e.code+'). Probando con '+AI.label[list[k+1]]+'.',4200);continue;}
        throw e;
      }
    }
    throw lastErr;
  };
  const sample=(i,o)=>call(i,o,false);
  sample.json=async(i,o)=>parseJsonLoose((await call(i,o,true)).text);
  sample.limits=async()=>({maxPromptBytes:250000,images:{maxCount:4,maxInputBytes:1e7,mediaTypes:['image/jpeg','image/png','image/webp','image/gif']}});
  return sample;
}
function makeDownloads(){
  return{save:async({filename,data})=>{
    const ext=(String(filename).split('.').pop()||'').toLowerCase();
    const types={json:'application/json',png:'image/png',mp4:'video/mp4',webm:'video/webm',txt:'text/plain',csv:'text/csv'};
    const blob=data instanceof Blob?data:new Blob([data],{type:types[ext]||'application/octet-stream'});
    const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=filename;a.rel='noopener';document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(u),60000);
    return{status:'saved'};
  }};
}
function setupAI(){
  CAP.sample=AI.configured().length?makeSample():null;
  CAP.images=!!CAP.sample;
  const needPin=!!(AI.status&&AI.status.pinRequired&&!AI.status.authorized);
  $('#pinBox').hidden=!needPin;
  $('#aiPanel').hidden=false;
}
async function initApp(){
  try{const pin=localStorage.getItem('jarvis.pin');if(pin)AI.pin=pin;}catch(e){}
  await AI.loadStatus();
  CAP.downloads=makeDownloads();
  S.storage='Este navegador, en este dispositivo (localStorage)';
  setupAI();
}
function aiRows(){
  if(!IS_APP)return[
    ['Claude (guiones y chat)',claudeOK()?'ok':CAP.sample?'warn':'no',claudeOK()?'Disponible. Usa tu cuota de Claude, no dinero.':CAP.sample?'Desactivado en Ajustes o sin permiso.':'No disponible en este visor.'],
    ['Claude con imágenes (analizar vídeos)',CAP.images&&claudeOK()?'ok':'no',CAP.images?'Disponible.':'No disponible.']];
  const rows=[['Servidor local de JARVIS',AI.status?'ok':'no',AI.status?(AI.status.pinRequired?'Conectado, protegido con PIN.':'Conectado.'):'No encontrado. Inicia «node server.js».']];
  if(AI.status&&AI.status.authorized!==false)AI.order.forEach(id=>{
    const i=AI.info(id);
    rows.push([AI.label[id]+' (API)',AI.usable(id)?'ok':(i.configured?'warn':'no'),i.configured?(AI.usable(id)?'Modelo: '+(S.settings.models[id]||i.model)+'. Cobra por uso a tu cuenta de API.':'Falta elegir modelo en Ajustes.'):'Sin clave. Usa «node setup.js».']);
  });
  rows.push(['IA con imágenes (analizar vídeos)',CAP.images&&claudeOK()?'ok':'no',CAP.images?'Disponible con el proveedor elegido.':'Necesita un proveedor con clave y modelo.']);
  return rows;
}
function renderAI(){
  const box=$('#aiRows');if(!box||!IS_APP)return;
  $('#ai-provider').value=S.settings.provider;
  if(!AI.status){box.innerHTML='<div class="note bad">No se encontró el servidor local. Inicia JARVIS con «node server.js» y abre http://localhost:8787. Mientras tanto funciona el modo gratuito local.</div>';return;}
  if(AI.status.authorized===false){box.innerHTML='<div class="small">Introduce el PIN en Inicio para ver los proveedores.</div>';return;}
  box.innerHTML=AI.order.map(id=>{
    const i=AI.info(id),cur=S.settings.models[id]||'',list=(AI.models[id]||[]).slice();
    if(cur&&!list.includes(cur))list.unshift(cur);
    const pill=!i.configured?'<span class="pill skip">Sin clave</span>':(AI.usable(id)?'<span class="pill ok">Lista</span>':'<span class="pill warn">Elige modelo</span>');
    const opts=[`<option value="">${i.model?esc('Predeterminado ('+i.model+')'):'Elige un modelo…'}</option>`].concat(list.map(m=>`<option value="${esc(m)}"${m===cur?' selected':''}>${esc(m)}</option>`)).join('');
    return`<div class="stack" style="gap:8px"><div class="spread"><b>${esc(AI.label[id])}</b>${pill}</div>${i.configured?`<div class="row"><select data-ai-model="${id}" aria-label="Modelo de ${esc(AI.label[id])}" style="flex:1">${opts}</select><button class="btn sm" data-ai-load="${id}">Cargar modelos</button></div>`:'<div class="small">Añade la clave con «node setup.js» y reinicia JARVIS.</div>'}</div>`;
  }).join('');
}
document.addEventListener('change',e=>{
  const t=e.target;if(!t||!t.dataset&&t.id!=='ai-provider')return;
  if(t.dataset&&t.dataset.aiModel){S.settings.models[t.dataset.aiModel]=t.value;saveSettings();renderAI();renderResources();renderTop();}
  if(t.id==='ai-provider'){S.settings.provider=t.value;saveSettings();renderAI();renderResources();renderTop();}
});
document.addEventListener('click',async e=>{
  const b=e.target.closest&&e.target.closest('[data-ai-load]');if(!b)return;
  b.disabled=true;b.textContent='Cargando…';
  try{const l=await AI.loadModels(b.dataset.aiLoad);toast(l.length+' modelos cargados.');}
  catch(err){handleSampleError(err);toast('No se pudo cargar la lista: '+(err.message||err.code),4200);logError('modelos',err);}
  renderAI();
});
$('#pinBtn').onclick=async()=>{
  AI.pin=$('#pinIn').value.trim();await AI.loadStatus();
  if(AI.status&&AI.status.authorized){try{localStorage.setItem('jarvis.pin',AI.pin);}catch(e){}toast('PIN correcto.');}
  else{AI.pin='';toast('PIN incorrecto.');}
  setupAI();renderAll();
};


/* ============================================================
   STORE · proyectos y ajustes
   ============================================================ */
const KEY_P='jarvis.projects.v1', KEY_S='jarvis.settings.v1';
const Store={
  db:null,
  loadLocal(){
    try{const a=JSON.parse(localStorage.getItem(KEY_P)||'[]'); if(Array.isArray(a))S.projects=a;}catch(e){}
    try{const s=JSON.parse(localStorage.getItem(KEY_S)||'null'); if(s)Object.assign(S.settings,s,{profiles:Object.assign(clone(PROFILES0),s.profiles||{})});}catch(e){}
  },
  persistLocal(){
    try{localStorage.setItem(KEY_P,JSON.stringify(S.projects));}catch(e){}
    try{localStorage.setItem(KEY_S,JSON.stringify(S.settings));}catch(e){}
  },
  async attachCloud(db){
    this.db=db; S.storage='Cuenta de Claude (db) + copia local';
    try{
      const [ps,ms]=await Promise.all([db.collection('jarvis_projects').get(),db.collection('jarvis_meta').doc('settings').get()]);
      ps.docs.forEach(d=>{
        const c=d.data(); if(!c||!c.id)return;
        const i=S.projects.findIndex(x=>x.id===c.id);
        if(i<0)S.projects.push(clone(c)); else if((c.updatedAt||0)>(S.projects[i].updatedAt||0))S.projects[i]=clone(c);
      });
      if(ms.exists){const s=ms.data(); Object.assign(S.settings,s,{profiles:Object.assign(clone(PROFILES0),s.profiles||{})});}
      this.persistLocal();
    }catch(e){logError('almacenamiento',e); S.storage='Navegador (local); la cuenta no respondió';}
  },
  save(p){
    p.updatedAt=Date.now(); this.persistLocal();
    if(!this.db)return;
    clearTimeout(this['t'+p.id]);
    this['t'+p.id]=setTimeout(()=>{this.db.collection('jarvis_projects').doc(p.id).set(clone(p)).catch(e=>logError('almacenamiento',e));},700);
  },
  saveSettings(){
    this.persistLocal();
    if(this.db)this.db.collection('jarvis_meta').doc('settings').set(clone(S.settings)).catch(e=>logError('almacenamiento',e));
  },
  remove(p){
    S.projects=S.projects.filter(x=>x.id!==p.id); this.persistLocal();
    if(this.db)this.db.collection('jarvis_projects').doc(p.id).delete().catch(e=>logError('almacenamiento',e));
  }
};
const saveP=p=>Store.save(p||S.cur);
const saveSettings=()=>Store.saveSettings();

function newProject(key='edu',over={}){
  const pr=S.settings.profiles[key]||S.settings.profiles.edu;
  return Object.assign({
    id:uid(),channel:pr.name,profile:key,topic:'',audience:pr.audience,language:'es',style:pr.style,narrator:pr.narrator,
    seconds:pr.seconds,aspect:S.settings.defaultAspect||'9:16',res:720,mood:pr.mood,music:true,subs:true,
    seed:Math.floor(Math.random()*900)+1,scenes:[],title:'',description:'',tags:[],verify:[],sources:[],history:[],
    videos:[],resources:[],publish:{status:'No publicado'},mix:{voice:90,music:45,sfx:50},
    createdAt:Date.now(),updatedAt:Date.now(),scriptSource:null
  },over);
}

/* ============================================================
   SCRIPT · guion, duración, plantilla local
   ============================================================ */
function estDur(text,lang){
  const w=String(text||'').trim().split(/\s+/).filter(Boolean).length;
  const wps={es:2.6,pt:2.6,en:2.8}[lang]||2.6;
  return Math.round(clamp(w/wps+0.5,2,14)*10)/10;
}
const totalDur=p=>(p&&p.scenes?p.scenes.reduce((a,s)=>a+(+s.seconds||0),0):0);
function timeline(p){let a=0;const starts=[];(p.scenes||[]).forEach(s=>{starts.push(a);a+=(+s.seconds||0);});return{starts,total:a};}

function scriptPrompt(p){
  const n=clamp(Math.round(p.seconds/5),4,14), words=Math.round(p.seconds*2.5);
  const prefs=S.settings.prefs.length?('Preferencias del usuario: '+S.settings.prefs.join('; ')+'\n'):'';
  return `Eres el motor de guiones de JARVIS, una app que monta vídeos cortos con escenas animadas.
Escribe un guion ORIGINAL en ${LANGN[p.language]||'español'}.
Canal: ${p.channel}. Tema: ${p.topic}. Público: ${p.audience}. Estilo visual: ${p.style}. Narrador: ${p.narrator}.
Formato de pantalla: ${p.aspect}. Duración objetivo: ${p.seconds} segundos, unas ${words} palabras de narración en total (≈2,5 palabras por segundo).
${prefs}Estructura: la primera escena es un gancho que atrapa en 3 segundos; después el desarrollo; la última es el cierre con una llamada a la acción.
Usa entre ${n-1} y ${n+1} escenas. "visual" es "title" (gancho), "number" (elementos de una lista numerada; pon el número en "number"), "statement" (frase destacada) o "image" (cuando una foto ayudaría).
"onscreen" es un texto corto en pantalla (máximo 8 palabras). "narration" es lo que se dice en voz alta, frases cortas.
No inventes estadísticas, citas, fechas ni noticias. Si no estás seguro de un dato, evítalo o dilo con cautela y añádelo a "verify". No tienes acceso a internet.
Devuelve SOLO un objeto JSON con esta forma exacta:
{"title":"título del vídeo, máximo 70 caracteres","description":"descripción para la plataforma, 2-3 frases","tags":["etiqueta"],"scenes":[{"narration":"…","onscreen":"…","visual":"title","number":null}],"verify":["afirmación concreta que el usuario debe comprobar antes de publicar"],"notes":"una frase"}`;
}
const TPL={
  es:{hook:t=>`¿Sabías esto sobre ${t}? Quédate hasta el final.`,hookOn:t=>t,body:(i,t)=>`Dato ${i}: [escribe aquí un dato verificado sobre ${t}].`,bodyOn:i=>`Dato ${i}`,outro:'¿Cuál te ha sorprendido más? Cuéntalo en los comentarios y sígueme para más.',outroOn:'¿Cuál te sorprendió?'},
  pt:{hook:t=>`Você sabia disso sobre ${t}? Fique até o final.`,hookOn:t=>t,body:(i,t)=>`Fato ${i}: [escreva aqui um fato verificado sobre ${t}].`,bodyOn:i=>`Fato ${i}`,outro:'Qual deles te surpreendeu mais? Conte nos comentários e me siga para mais.',outroOn:'Qual te surpreendeu?'},
  en:{hook:t=>`Did you know this about ${t}? Stay until the end.`,hookOn:t=>t,body:(i,t)=>`Fact ${i}: [write a verified fact about ${t} here].`,bodyOn:i=>`Fact ${i}`,outro:'Which one surprised you most? Tell me in the comments and follow for more.',outroOn:'Which surprised you?'}
};
function mkScene(o,lang){
  const s=Object.assign({id:uid(),narration:'',onscreen:'',visual:'statement',number:null,seed:Math.floor(Math.random()*9)+1,seconds:0},o);
  if(!s.seconds)s.seconds=estDur(s.narration||s.onscreen,lang);
  return s;
}
function templateScript(p){
  const L=TPL[p.language]||TPL.es, t=p.topic||'tu tema';
  const n=clamp(Math.round(p.seconds/6),3,9);
  const sc=[mkScene({narration:L.hook(t),onscreen:L.hookOn(t).slice(0,60),visual:'title'},p.language)];
  for(let i=1;i<=n;i++)sc.push(mkScene({narration:L.body(i,t),onscreen:L.bodyOn(i),visual:'number',number:i},p.language));
  sc.push(mkScene({narration:L.outro,onscreen:L.outroOn,visual:'statement'},p.language));
  return{title:t.slice(0,70),description:'',tags:[],scenes:sc,verify:['Plantilla local sin IA: sustituye los textos entre [corchetes] por datos verificados.'],notes:'template'};
}
function normalizeScript(j,p){
  const raw=Array.isArray(j&&j.scenes)?j.scenes:[];
  const scenes=raw.map((s,i)=>mkScene({
    narration:String(s.narration||s.text||'').trim(),
    onscreen:String(s.onscreen||'').trim().slice(0,80),
    visual:['title','number','statement','image'].includes(s.visual)?s.visual:(i===0?'title':'statement'),
    number:(s.number!=null&&Number.isFinite(+s.number))?+s.number:null
  },p.language)).filter(s=>s.narration||s.onscreen);
  return{
    title:String(j.title||p.topic||'').slice(0,100),description:String(j.description||'').slice(0,900),
    tags:(Array.isArray(j.tags)?j.tags:[]).map(x=>String(x).slice(0,40)).slice(0,15),
    verify:(Array.isArray(j.verify)?j.verify:[]).map(x=>String(x).slice(0,240)).slice(0,12),
    scenes,notes:String(j.notes||'')
  };
}
function handleSampleError(e){
  const code=e&&e.code;
  if(NOSE.has(code)){CAP.blocked=true;toast('La IA no está disponible aquí. JARVIS sigue en modo gratuito local.');renderTop();renderResources();}
  else if(code==='rate_limited')toast(aiName()+' alcanzó un límite de uso. Inténtalo más tarde.');
  else if(code==='auth')toast('La clave de la IA no es válida o no tiene permiso. Revisa el archivo .env.');
  else if(code==='quota')toast('La cuenta de la IA no tiene saldo o cuota. JARVIS sigue en modo local.');
  else if(code==='no_model'||code==='bad_model')toast('Elige un modelo válido en Ajustes, sección Proveedores de IA.');
}
async function generateScript(p){
  if(claudeOK()){
    try{
      const j=await CAP.sample.json(scriptPrompt(p),{modelTier:'default',cache:false});
      const out=normalizeScript(j,p);
      if(out.scenes.length>=3)return Object.assign(out,{source:'ai'});
      throw new Error(aiName()+' devolvió menos de 3 escenas válidas');
    }catch(e){handleSampleError(e);logError('guion',e);}
  }
  return Object.assign(templateScript(p),{source:'template'});
}
function applyScript(p,res){
  if(p.scenes.length){
    p.history.unshift({t:Date.now(),title:p.title,source:p.scriptSource,scenes:p.scenes.map(s=>({n:s.narration,o:s.onscreen}))});
    p.history=p.history.slice(0,5);
  }
  p.title=res.title||p.title; p.description=res.description; p.tags=res.tags; p.verify=res.verify;
  p.scenes=res.scenes; p.scriptSource=res.source;
  p.sources=[{kind:'nota',text:res.source==='ai'?'Datos de '+aiName()+' sin búsqueda web. No verificados.':'Plantilla local sin datos.'}];
}
async function regenScene(p,i){
  const sc=p.scenes[i]; if(!sc)return;
  sc.seed=(sc.seed||0)+1;
  if(claudeOK()){
    try{
      const ctx=p.scenes.map((s,k)=>`${k+1}. ${s.narration}`).join('\n');
      const j=await CAP.sample.json(`Reescribe SOLO la escena ${i+1} de este guion en ${LANGN[p.language]}, con otro enfoque y la misma duración aproximada (${sc.seconds} s). Tema: ${p.topic}. Escenas actuales:\n${ctx}\nNo inventes datos. Devuelve SOLO JSON: {"narration":"…","onscreen":"texto corto en pantalla"}`,{modelTier:'quick',cache:false});
      if(j&&j.narration){sc.narration=String(j.narration).trim();sc.onscreen=String(j.onscreen||sc.onscreen).slice(0,80);sc.seconds=estDur(sc.narration,p.language);}
      toast('Escena regenerada con '+aiName()+'.');
    }catch(e){handleSampleError(e);logError('escena',e);toast('No se pudo reescribir. Se cambió solo la variante visual.');}
  }else toast('Variante visual nueva. Sin IA no se reescribe el texto.');
  saveP(p);
}

/* ============================================================
   RENDER · fondos y escenas dibujadas en canvas
   ============================================================ */
const FD='"Outfit",system-ui,sans-serif', FB='"Instrument Sans",system-ui,sans-serif';
const ASP={'9:16':[9,16],'16:9':[16,9],'1:1':[1,1]};
function dims(p){
  const sh=({480:480,720:720,1080:1080})[+p.res]||720, [a,b]=ASP[p.aspect]||[9,16]; let W,H;
  if(a===b){W=H=sh;}else if(a<b){W=sh;H=Math.round(sh*b/a);}else{H=sh;W=Math.round(sh*a/b);}
  return{W:W-W%2,H:H-H%2};
}
const palOf=p=>((S.settings.profiles[p.profile]||S.settings.profiles.edu).pal)||PROFILES0.edu.pal;
const bgOf=p=>((S.settings.profiles[p.profile]||{}).bg)||(PROFILES0[p.profile]||PROFILES0.edu).bg;
function hexA(h,a){h=String(h).replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');const n=parseInt(h,16);return`rgba(${n>>16&255},${n>>8&255},${n&255},${a})`;}
function rnd(seed){let a=seed>>>0;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function rr(c,x,y,w,h,r){r=Math.min(r,w/2,h/2);c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();}
function wrap(c,text,maxW){
  const words=String(text).split(/\s+/).filter(Boolean),lines=[];let cur='';
  for(const w of words){const t=cur?cur+' '+w:w; if(c.measureText(t).width<=maxW||!cur)cur=t; else{lines.push(cur);cur=w;}}
  if(cur)lines.push(cur); return lines;
}
function fit(c,text,maxW,maxLines,start,min,weight,fam){
  let size=start,lines=[];
  for(;size>=min;size-=2){c.font=`${weight} ${size}px ${fam}`;lines=wrap(c,text,maxW);if(lines.length<=maxLines&&lines.every(l=>c.measureText(l).width<=maxW))break;}
  if(lines.length>maxLines){lines=lines.slice(0,maxLines);lines[maxLines-1]=lines[maxLines-1].replace(/\s*\S*$/,'…');}
  return{size,lines};
}
function drawBg(c,W,H,T,P,kind,seed){
  const g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,P[0]);g.addColorStop(1,hexA(P[1],0.55));
  c.fillStyle=P[0];c.fillRect(0,0,W,H);c.fillStyle=g;c.fillRect(0,0,W,H);
  const R=Math.max(W,H);
  for(let i=0;i<3;i++){
    const ph=seed*1.7+i*2.1,x=W*(0.5+0.4*Math.sin(T*0.22+ph)),y=H*(0.5+0.4*Math.cos(T*0.18+ph*1.3));
    const rg=c.createRadialGradient(x,y,0,x,y,R*(0.5+0.08*i));rg.addColorStop(0,hexA(i===1?P[2]:P[1],[0.55,0.2,0.42][i]));rg.addColorStop(1,'rgba(0,0,0,0)');
    c.fillStyle=rg;c.fillRect(0,0,W,H);
  }
  c.save();
  if(kind==='grid'){
    const vy=H*0.56;c.strokeStyle=hexA(P[2],0.28);c.lineWidth=Math.max(1,W/500);
    for(let k=0;k<14;k++){const f=((k+(T*0.7)%1)/14);const y=vy+(H-vy)*f*f;c.beginPath();c.moveTo(0,y);c.lineTo(W,y);c.stroke();}
    for(let i=-9;i<=9;i++){c.beginPath();c.moveTo(W/2+i*W*0.012,vy);c.lineTo(W/2+i*W*0.13,H);c.stroke();}
  }else if(kind==='bokeh'){
    const r=rnd(seed*7+3);
    for(let i=0;i<16;i++){const bx=r()*W,by=r()*H,br=(0.04+r()*0.1)*R,sp=0.05+r()*0.1,ph=r()*6;
      const x=bx+Math.sin(T*sp+ph)*W*0.06,y=by+Math.cos(T*sp*0.8+ph)*H*0.05;
      const rg=c.createRadialGradient(x,y,0,x,y,br);rg.addColorStop(0,hexA(P[2+(i%2)],0.2));rg.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=rg;c.fillRect(x-br,y-br,br*2,br*2);}
  }else if(kind==='brushed'){
    c.strokeStyle=hexA(P[3],0.06);c.lineWidth=1;
    for(let i=-H;i<W;i+=Math.max(8,W/60)){c.beginPath();c.moveTo(i,0);c.lineTo(i+H*0.5,H);c.stroke();}
    const sx=((T*0.12)%1.6-0.3)*W,sg=c.createLinearGradient(sx-W*0.2,0,sx+W*0.2,0);
    sg.addColorStop(0,'rgba(0,0,0,0)');sg.addColorStop(0.5,hexA(P[2],0.12));sg.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=sg;c.fillRect(0,0,W,H);
  }else{
    const cx=W/2,cy=H*0.42;c.strokeStyle=hexA(P[2],0.22);c.lineWidth=Math.max(1,W/400);
    for(let k=1;k<=4;k++){c.beginPath();c.arc(cx,cy,R*0.12*k,T*0.2*(k%2?1:-1),T*0.2*(k%2?1:-1)+Math.PI*1.35);c.stroke();}
    c.fillStyle=hexA(P[2],0.16);for(let x=W*0.08;x<W;x+=W*0.09)for(let y=H*0.06;y<H;y+=H*0.07){c.fillRect(x,y,2,2);}
  }
  c.restore();
  const v=c.createRadialGradient(W/2,H/2,R*0.3,W/2,H/2,R*0.8);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,0.55)');c.fillStyle=v;c.fillRect(0,0,W,H);
}
function drawCover(c,im,W,H,z,px,py){
  const iw=im.width||im.naturalWidth,ih=im.height||im.naturalHeight;if(!iw||!ih)return;
  const s=Math.max(W/iw,H/ih)*z,w=iw*s,h=ih*s;
  c.drawImage(im,(W-w)*px,(H-h)*py,w,h);
}
function blockText(c,lines,size,x,y,align,color,lh){
  c.textAlign=align;c.textBaseline='alphabetic';c.fillStyle=color;
  c.shadowColor='rgba(0,0,0,.55)';c.shadowBlur=size*0.3;
  lines.forEach((l,i)=>c.fillText(l,x,y+i*size*lh));
  c.shadowBlur=0;
}
function drawFg(c,W,H,u,T,P,p,sc,idx,st,dur){
  const inA=ease(clamp(st/0.5,0,1)),outA=clamp((dur-st)/0.3,0,1),a=inA*outA,slide=(1-inA)*u*4;
  const accent=(sc.seed%2)?P[3]:P[2],left=(sc.seed%3)===0&&H>=W,vert=H>=W;
  const mx=W*0.08,maxW=W-2*mx,text=(sc.onscreen||'').trim()||(sc.narration||'').slice(0,70);
  c.save();c.globalAlpha=a;
  if(sc.visual==='image'&&MEDIA.img[sc.id]){
    const k=st/Math.max(dur,1),dir=(sc.seed%2)?1:-1;
    c.save();c.globalAlpha=a;drawCover(c,MEDIA.img[sc.id].bmp,W,H,1+0.12*k,0.5+0.1*dir*(k-0.5),0.5);c.restore();
    const gr=c.createLinearGradient(0,H*0.45,0,H);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba(0,0,0,.78)');c.fillStyle=gr;c.fillRect(0,0,W,H);
    const f=fit(c,text,maxW,3,u*(vert?8:7),u*4,700,FD);c.font=`700 ${f.size}px ${FD}`;
    blockText(c,f.lines,f.size,mx,H*(vert?0.66:0.62)+slide,'left','#fff',1.12);
  }else if(sc.visual==='number'&&sc.number!=null){
    c.font=`700 ${Math.min(W,H)*0.92}px ${FD}`;c.textAlign='center';c.textBaseline='middle';
    c.lineWidth=Math.max(2,u*0.5);c.strokeStyle=hexA(accent,0.22);c.strokeText(String(sc.number),W/2,H*(vert?0.34:0.46));
    c.fillStyle=hexA(accent,0.08);c.fillText(String(sc.number),W/2,H*(vert?0.34:0.46));
    const f=fit(c,text,maxW,3,u*(vert?9:8),u*4.5,700,FD);c.font=`700 ${f.size}px ${FD}`;
    blockText(c,f.lines,f.size,W/2,H*(vert?0.54:0.52)+slide-(f.lines.length-1)*f.size*0.5,'center','#fff',1.12);
    c.fillStyle=accent;c.fillRect(W/2-u*6*inA,H*(vert?0.54:0.52)+f.size*1.2+slide,u*12*inA,Math.max(3,u*0.55));
  }else if(sc.visual==='title'){
    c.font=`600 ${u*2.8}px ${FD}`;c.textAlign='center';c.fillStyle=accent;c.letterSpacing=`${u*0.5}px`;
    c.fillText(String(p.channel||'').toUpperCase().slice(0,32),W/2,H*(vert?0.32:0.3)+slide);c.letterSpacing='0px';
    const f=fit(c,text,maxW,4,u*(vert?11:9.5),u*5,700,FD);c.font=`700 ${f.size}px ${FD}`;
    blockText(c,f.lines,f.size,W/2,H*(vert?0.42:0.44)+slide,'center','#fff',1.1);
    c.fillStyle=accent;c.fillRect(W/2-u*8*inA,H*(vert?0.42:0.44)+f.lines.length*f.size*1.1+u,u*16*inA,Math.max(3,u*0.6));
  }else{
    if(sc.visual==='image'){ // sin imagen adjunta: anillos generados
      c.strokeStyle=hexA(accent,0.55);c.lineWidth=Math.max(2,u*0.5);
      for(let k=1;k<=4;k++){c.beginPath();c.arc(W/2,H*(vert?0.3:0.42),u*k*5*(0.9+0.1*Math.sin(T*2+k)),0,Math.PI*2);c.globalAlpha=a*(1-k*0.18);c.stroke();}
      c.globalAlpha=a;
    }
    const f=fit(c,text,maxW,5,u*(vert?9.5:8),u*4.5,700,FD);c.font=`700 ${f.size}px ${FD}`;
    const al=left?'left':'center',x=left?mx:W/2,y=H*(vert?0.46:0.5)-(f.lines.length-1)*f.size*0.5;
    blockText(c,f.lines,f.size,x,y+slide,al,'#fff',1.14);
  }
  c.restore();
}
function drawSubs(c,W,H,u,sc,st,dur,P){
  const words=String(sc.narration||'').trim().split(/\s+/).filter(Boolean);if(!words.length)return;
  const lead=0.2,tail=Math.min(0.4,dur*0.15),prog=clamp((st-lead)/Math.max(0.5,dur-lead-tail),0,0.9999);
  const chunks=[];let cur=[];
  words.forEach((w,i)=>{cur.push(i);if(cur.length>=5||(/[.!?:;¿¡]$/.test(w)&&cur.length>=2)){chunks.push(cur);cur=[];}});
  if(cur.length)chunks.push(cur);
  const wi=Math.floor(prog*words.length),ci=Math.max(0,chunks.findIndex(k=>k.includes(wi))),ch=chunks[ci];
  const vert=H>=W,fs=u*(vert?4.4:3.7);c.font=`600 ${fs}px ${FB}`;
  const sp=c.measureText(' ').width,maxW=W*0.86,lines=[];let ln={w:[],width:0};
  ch.forEach(i=>{const w=c.measureText(words[i]).width,add=ln.w.length?sp:0;
    if(ln.width+add+w>maxW&&ln.w.length){lines.push(ln);ln={w:[],width:0};}
    ln.width+=(ln.w.length?sp:0)+w;ln.w.push({t:words[i],i,w});});
  lines.push(ln);
  const lh=fs*1.3,bw=Math.max(...lines.map(l=>l.width))+u*3.4,bh=lines.length*lh+u*1.8;
  const by=H*(vert?0.80:0.9)-bh,bx=(W-bw)/2;
  c.save();c.fillStyle='rgba(2,6,16,.62)';rr(c,bx,by,bw,bh,u*1.4);c.fill();c.textBaseline='alphabetic';c.textAlign='left';
  lines.forEach((l,k)=>{let x=(W-l.width)/2;const y=by+u*0.9+lh*k+fs;
    l.w.forEach(o=>{c.fillStyle=o.i===wi?P[2]:'#ffffff';c.fillText(o.t,x,y);x+=o.w+sp;});});
  c.restore();
}
function renderFrame(c,W,H,t,p,o={}){
  const P=palOf(p),tl=timeline(p),total=tl.total,u=Math.min(W,H)/100;
  const T=clamp(t,0,Math.max(total-0.001,0));
  drawBg(c,W,H,T,P,bgOf(p),p.seed||1);
  if(!p.scenes.length){
    c.fillStyle='rgba(232,242,255,.7)';c.font=`600 ${u*4.6}px ${FD}`;c.textAlign='center';
    c.fillText('Sin escenas todavía',W/2,H*0.46);c.font=`400 ${u*3.2}px ${FB}`;c.fillText('Genera el guion para ver el vídeo',W/2,H*0.46+u*6);return;
  }
  let idx=0;for(let i=0;i<tl.starts.length;i++)if(T>=tl.starts[i])idx=i;
  const sc=p.scenes[idx],st=T-tl.starts[idx],dur=+sc.seconds||1;
  drawFg(c,W,H,u,T,P,p,sc,idx,st,dur);
  if(!o.noSubs&&p.subs!==false)drawSubs(c,W,H,u,sc,st,dur,P);
  if(!o.noProgress){
    c.fillStyle=P[2];c.fillRect(0,0,W*(T/total),Math.max(3,u*0.6));
    c.fillStyle='rgba(255,255,255,.45)';c.font=`500 ${u*2.4}px ${FB}`;c.textAlign='left';c.textBaseline='alphabetic';
    c.fillText(String(p.channel||'').slice(0,28),u*3,H-u*3.2);
  }
  const f=Math.max(clamp(1-T/0.4,0,1)*0.9,clamp((T-(total-0.6))/0.6,0,1));
  if(f>0){c.fillStyle=`rgba(0,0,0,${f})`;c.fillRect(0,0,W,H);}
}

/* ============================================================
   AUDIO · música generativa, efectos, pistas del usuario
   ============================================================ */
const mtof=n=>440*Math.pow(2,(n-69)/12);
const MOODS={
  energetic:{bpm:116,roots:[57,53,60,55],minor:[1,0,0,0],arp:true,kick:'all',lp:2600,pad:0.032},
  calm:{bpm:58,roots:[48,45,41,43],minor:[0,1,0,0],arp:false,kick:null,noise:true,lp:700,pad:0.05},
  industrial:{bpm:92,roots:[38,38,41,36],minor:[1,1,0,0],arp:false,kick:'half',tick:true,lp:900,pad:0.04},
  bright:{bpm:100,roots:[48,43,45,41],minor:[0,0,1,0],arp:true,kick:null,lp:2100,pad:0.034}
};
const engine={
  ac:null,timer:null,noiseBuf:null,srcs:[],
  async ensure(){
    if(!this.ac){
      const AC=window.AudioContext||window.webkitAudioContext;
      if(!AC)throw new Error('Este navegador no tiene Web Audio.');
      const ac=this.ac=new AC();
      this.master=ac.createGain();this.comp=ac.createDynamicsCompressor();
      this.musicFade=ac.createGain();this.musicBus=ac.createGain();this.sfxBus=ac.createGain();this.voiceBus=ac.createGain();
      this.musicFade.connect(this.musicBus);this.musicBus.connect(this.master);this.sfxBus.connect(this.master);this.voiceBus.connect(this.master);
      this.master.connect(this.comp);
      this.dest=ac.createMediaStreamDestination();this.comp.connect(this.dest);
      this.spk=ac.createGain();this.comp.connect(this.spk);this.spk.connect(ac.destination);
      const nb=ac.createBuffer(1,ac.sampleRate*2,ac.sampleRate),d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;this.noiseBuf=nb;
    }
    if(this.ac.state!=='running')await this.ac.resume().catch(()=>{});
    this.applyMix();
  },
  mixOf(){const p=getP();const m=(p&&p.mix)||{voice:90,music:45,sfx:50};return{voice:m.voice/100,music:m.music/100,sfx:m.sfx/100};},
  applyMix(){if(!this.ac)return;const m=this.mixOf(),t=this.ac.currentTime;
    this.voiceBus.gain.setTargetAtTime(m.voice,t,0.02);this.musicBus.gain.setTargetAtTime(m.music,t,0.02);this.sfxBus.gain.setTargetAtTime(m.sfx,t,0.02);},
  start(p,{speaker=true,from=0}={}){
    this.stop();const ac=this.ac;if(!ac)return;
    this.spk.gain.value=speaker?1:0;this.applyMix();
    const t0=ac.currentTime+0.06;
    this.musicFade.gain.cancelScheduledValues(t0);this.musicFade.gain.setValueAtTime(0,t0);this.musicFade.gain.linearRampToValueAtTime(1,t0+0.6);
    if(p.music!==false){
      const m=MOODS[p.mood]||MOODS.bright;this.m=m;this.bar=0;this.nextBar=t0;
      const tick=()=>{while(this.nextBar<ac.currentTime+1.6){this.scheduleBar(this.nextBar,this.bar++,m);this.nextBar+=240/m.bpm;}};
      tick();this.timer=setInterval(tick,250);
      if(m.noise){const s=ac.createBufferSource();s.buffer=this.noiseBuf;s.loop=true;const f=ac.createBiquadFilter();f.type='lowpass';f.frequency.value=650;const g=ac.createGain();g.gain.value=0.05;s.connect(f);f.connect(g);g.connect(this.musicFade);s.start(t0);this.srcs.push(s);}
      if(MEDIA.music){const s=ac.createBufferSource();s.buffer=MEDIA.music;s.loop=true;const g=ac.createGain();g.gain.value=0.7;s.connect(g);g.connect(this.musicFade);s.start(t0,from%MEDIA.music.duration);this.srcs.push(s);}
    }
    if(MEDIA.voice&&from<MEDIA.voice.duration){const s=ac.createBufferSource();s.buffer=MEDIA.voice;s.connect(this.voiceBus);s.start(t0,from);this.srcs.push(s);}
  },
  stop(){
    if(this.timer){clearInterval(this.timer);this.timer=null;}
    if(!this.ac)return;
    this.srcs.forEach(s=>{try{s.stop();}catch(e){}});this.srcs=[];
    this.musicFade.gain.cancelScheduledValues(this.ac.currentTime);this.musicFade.gain.setTargetAtTime(0,this.ac.currentTime,0.03);
  },
  fadeOut(sec){if(!this.ac)return;this.musicFade.gain.cancelScheduledValues(this.ac.currentTime);this.musicFade.gain.setTargetAtTime(0,this.ac.currentTime,sec/3);},
  scheduleBar(t0,bar,m){
    const beat=60/m.bpm,barD=beat*4,root=m.roots[bar%m.roots.length],minor=m.minor[bar%4];
    const chord=[0,minor?3:4,7].map(x=>root+12+x);
    chord.forEach(n=>this.pad(mtof(n),t0,barD,m));
    const bassN=m.kick==='all'?8:(m.kick==='half'?4:2);
    for(let i=0;i<bassN;i++)this.tone('sine',mtof(root-12),t0+i*barD/bassN,Math.min(0.5,barD/bassN),0.16);
    if(m.arp){const seq=[0,1,2,1,2,1,0,2];for(let i=0;i<8;i++)this.tone('triangle',mtof(chord[seq[i]]+12),t0+i*beat/2,0.22,0.05);}
    if(m.kick){for(let b=0;b<4;b++){if(m.kick==='half'&&b%2)continue;this.kick(t0+b*beat);}}
    if(m.tick){for(let b=1;b<4;b+=2)this.noiseHit(t0+b*beat,0.05,5000,0.07);}
  },
  pad(f,t,d,m){
    const ac=this.ac,g=ac.createGain(),lp=ac.createBiquadFilter();lp.type='lowpass';lp.frequency.value=m.lp;lp.Q.value=0.6;
    g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(m.pad,t+Math.min(0.8,d*0.3));g.gain.setValueAtTime(m.pad,t+d-0.2);g.gain.linearRampToValueAtTime(0,t+d+0.5);
    [['sawtooth',-7],['triangle',6]].forEach(([ty,dt])=>{const o=ac.createOscillator();o.type=ty;o.frequency.value=f;o.detune.value=dt;o.connect(lp);o.start(t);o.stop(t+d+0.6);});
    lp.connect(g);g.connect(this.musicFade);
  },
  tone(type,f,t,d,vol){
    const ac=this.ac,o=ac.createOscillator(),g=ac.createGain();o.type=type;o.frequency.value=f;
    g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(vol,t+0.005);g.gain.linearRampToValueAtTime(0,t+d);
    o.connect(g);g.connect(this.musicFade);o.start(t);o.stop(t+d+0.05);
  },
  kick(t){
    const ac=this.ac,o=ac.createOscillator(),g=ac.createGain();o.type='sine';o.frequency.setValueAtTime(130,t);o.frequency.exponentialRampToValueAtTime(42,t+0.13);
    g.gain.setValueAtTime(0.32,t);g.gain.linearRampToValueAtTime(0,t+0.2);o.connect(g);g.connect(this.musicFade);o.start(t);o.stop(t+0.25);
  },
  noiseHit(t,d,hp,vol){
    const ac=this.ac,s=ac.createBufferSource();s.buffer=this.noiseBuf;const f=ac.createBiquadFilter();f.type='highpass';f.frequency.value=hp;
    const g=ac.createGain();g.gain.setValueAtTime(vol,t);g.gain.linearRampToValueAtTime(0,t+d);s.connect(f);f.connect(g);g.connect(this.musicFade);s.start(t,Math.random());s.stop(t+d+0.02);
  },
  whoosh(){
    if(!this.ac||this.ac.state!=='running')return;
    const ac=this.ac,t=ac.currentTime,s=ac.createBufferSource();s.buffer=this.noiseBuf;
    const f=ac.createBiquadFilter();f.type='bandpass';f.Q.value=1.2;f.frequency.setValueAtTime(350,t);f.frequency.exponentialRampToValueAtTime(3200,t+0.32);
    const g=ac.createGain();g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(0.35,t+0.12);g.gain.linearRampToValueAtTime(0,t+0.4);
    s.connect(f);f.connect(g);g.connect(this.sfxBus);s.start(t,Math.random());s.stop(t+0.45);
  },
  async decode(file){await this.ensure();const buf=await file.arrayBuffer();return await new Promise((res,rej)=>this.ac.decodeAudioData(buf,res,rej));}
};

/* ---------- narración del dispositivo (solo vista previa) ---------- */
function pickVoice(lang,gender){
  if(!('speechSynthesis' in window))return null;
  const vs=speechSynthesis.getVoices().filter(v=>v.lang&&v.lang.toLowerCase().startsWith(lang));if(!vs.length)return null;
  const pref=gender==='masculina'?/male|hombre|jorge|diego|juan|pablo|daniel|antonio|felipe|ricardo|google/i:/female|mujer|helena|m[oó]nica|paulina|luciana|sabina|maria|francisca|google/i;
  return vs.find(v=>pref.test(v.name))||vs[0];
}
function speakScene(p,i){
  if(!('speechSynthesis' in window))return;
  speechSynthesis.cancel();
  if(p.narrator==='sin voz'||MEDIA.voice||!$('#ttsOn').checked)return;
  const sc=p.scenes[i];if(!sc||!sc.narration)return;
  const u=new SpeechSynthesisUtterance(sc.narration),v=pickVoice(p.language,p.narrator);
  if(v)u.voice=v;u.lang=v?v.lang:p.language;
  u.rate=clamp((estDur(sc.narration,p.language)-0.5)/Math.max(1.5,sc.seconds-0.4),0.8,1.4);
  u.pitch=p.narrator==='masculina'?0.85:1.05;u.volume=engine.mixOf().voice;
  speechSynthesis.speak(u);
}

/* ============================================================
   PLAYER · reproducción y grabación sobre el mismo canvas
   ============================================================ */
const cv=$('#cv'),cx=cv.getContext('2d');
const player={
  t:0,playing:false,raf:0,opts:{},lastIdx:-1,fading:false,
  fit(){const p=getP();if(!p)return;const{W,H}=dims(p);if(cv.width!==W||cv.height!==H){cv.width=W;cv.height=H;}},
  total(){return totalDur(getP());},
  still(){const p=getP();if(!p)return;this.fit();renderFrame(cx,cv.width,cv.height,this.t,p);this.ui();},
  ui(){
    const tot=this.total();$('#timeLbl').textContent=fmtT(this.t)+' / '+fmtT(tot);
    if(document.activeElement!==$('#seek'))$('#seek').value=tot?Math.round(this.t/tot*1000):0;
    $('#playBtn').textContent=this.playing?'Pausa':'Reproducir';
  },
  async play(opts={}){
    const p=getP();if(!p||!p.scenes.length||this.playing)return;
    await engine.ensure().catch(e=>{logError('audio',e);});
    const total=this.total();if(this.t>=total-0.05)this.t=0;
    this.playing=true;this.opts=opts;this.lastIdx=-1;this.fading=false;this.fit();
    if(engine.ac)engine.start(p,{speaker:opts.speaker!==false,from:this.t});
    const t0=performance.now()-this.t*1000;
    const loop=()=>{
      if(!this.playing)return;
      this.t=(performance.now()-t0)/1000;
      if(this.t>=total){this.t=total;renderFrame(cx,cv.width,cv.height,this.t,p);this.finish();return;}
      const idx=timelineIdx(p,this.t);
      if(idx!==this.lastIdx){this.lastIdx=idx;if(opts.speak!==false)speakScene(p,idx);if(idx>0)engine.whoosh();}
      if(!this.fading&&total-this.t<1.4){this.fading=true;engine.fadeOut(1.2);}
      renderFrame(cx,cv.width,cv.height,this.t,p);this.ui();
      if(opts.onTick)opts.onTick(this.t,total);
      this.raf=requestAnimationFrame(loop);
    };
    loop();
  },
  pause(){this.playing=false;cancelAnimationFrame(this.raf);engine.stop();if('speechSynthesis' in window)speechSynthesis.cancel();this.ui();},
  finish(){const cb=this.opts.onEnd;this.playing=false;cancelAnimationFrame(this.raf);engine.stop();if('speechSynthesis' in window)speechSynthesis.cancel();this.ui();if(cb)cb();},
  seek(t){const was=this.playing,o=this.opts;if(was)this.pause();this.t=clamp(t,0,this.total());this.still();if(was)this.play(o);}
};
function timelineIdx(p,t){const tl=timeline(p);let idx=0;for(let i=0;i<tl.starts.length;i++)if(t>=tl.starts[i])idx=i;return idx;}

/* ============================================================
   EXPORT · grabación real con MediaRecorder y verificación
   ============================================================ */
function pickMime(){
  if(!window.MediaRecorder)return null;
  const c=['video/mp4;codecs=avc1.42E01E,mp4a.40.2','video/mp4;codecs=avc1','video/mp4','video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'];
  return c.find(m=>{try{return MediaRecorder.isTypeSupported(m);}catch(e){return false;}})||'';
}
const canRecord=()=>!!(window.MediaRecorder&&HTMLCanvasElement.prototype.captureStream&&(window.AudioContext||window.webkitAudioContext));
async function recordVideo(p,onPct){
  if(!canRecord())throw new Error('Este navegador no puede grabar el lienzo (MediaRecorder/captureStream).');
  await engine.ensure();
  const mime=pickMime();player.pause();player.t=0;player.fit();player.still();
  try{await document.fonts.load('700 40px "Outfit"');await document.fonts.load('600 30px "Instrument Sans"');}catch(e){}
  const vs=cv.captureStream(30),stream=new MediaStream([...vs.getVideoTracks(),...engine.dest.stream.getAudioTracks()]);
  const px=cv.width*cv.height,bps=clamp(Math.round(px*30*0.09),1.5e6,12e6);
  let rec;try{rec=new MediaRecorder(stream,{mimeType:mime||undefined,videoBitsPerSecond:bps,audioBitsPerSecond:128000});}
  catch(e){rec=new MediaRecorder(stream);}
  const chunks=[];rec.ondataavailable=e=>{if(e.data&&e.data.size)chunks.push(e.data);};
  const stopped=new Promise((res,rej)=>{rec.onstop=res;rec.onerror=e=>rej((e&&e.error)||new Error('Error del grabador'));});
  let hidden=false;const vis=()=>{if(document.hidden)hidden=true;};document.addEventListener('visibilitychange',vis);
  let wl=null;try{if(navigator.wakeLock)wl=await navigator.wakeLock.request('screen');}catch(e){}
  rec.start(500);
  await new Promise(res=>{player.play({speaker:false,speak:false,onTick:(t,tot)=>onPct&&onPct(Math.round(t/tot*100)),onEnd:res});});
  await sleep(400);
  if(rec.state!=='inactive')rec.stop();
  await stopped;
  document.removeEventListener('visibilitychange',vis);try{wl&&wl.release();}catch(e){}
  vs.getTracks().forEach(t=>t.stop());
  if(S.abort){S.abort=false;throw Object.assign(new Error('Grabación cancelada'),{cancelled:true});}
  const type=(mime||'video/webm').split(';')[0],ext=type.includes('mp4')?'mp4':'webm';
  const blob=new Blob(chunks,{type});
  return{blob,mime:type,ext,hidden};
}
function waitEvt(el,evt,ms){
  return new Promise((res,rej)=>{
    const to=setTimeout(()=>{cleanup();rej(new Error('Tiempo agotado esperando «'+evt+'»'));},ms);
    const ok=()=>{cleanup();res();},bad=()=>{cleanup();rej(new Error('El navegador no pudo leer el archivo de vídeo'));};
    function cleanup(){clearTimeout(to);el.removeEventListener(evt,ok);el.removeEventListener('error',bad);}
    el.addEventListener(evt,ok);el.addEventListener('error',bad);
  });
}
async function verifyVideo(blob,p,ext){
  const checks=[],exp=totalDur(p),{W,H}=dims(p);
  checks.push({n:'El archivo existe y tiene contenido',ok:blob.size>20000,v:fmtSize(blob.size)});
  const url=URL.createObjectURL(blob),v=document.createElement('video');v.muted=true;v.playsInline=true;v.preload='auto';v.src=url;
  try{
    await waitEvt(v,'loadedmetadata',10000);
    if(!isFinite(v.duration)||v.duration===0){v.currentTime=1e7;await waitEvt(v,'timeupdate',5000).catch(()=>{});}
    const d=v.duration;
    checks.push({n:'Se puede abrir y leer',ok:isFinite(d)&&d>0,v:isFinite(d)?d.toFixed(1)+' s':'duración ilegible'});
    checks.push({n:'Duración esperada ('+exp.toFixed(1)+' s)',ok:isFinite(d)&&Math.abs(d-exp)<=Math.max(1.5,exp*0.06),v:isFinite(d)?d.toFixed(1)+' s':'—'});
    checks.push({n:'Resolución esperada ('+W+'×'+H+')',ok:v.videoWidth===W&&v.videoHeight===H,v:v.videoWidth+'×'+v.videoHeight});
    v.currentTime=0;await sleep(60);
    try{await v.play();await sleep(700);checks.push({n:'Se reproduce',ok:v.currentTime>0.2,v:v.currentTime.toFixed(1)+' s avanzados'});v.pause();}
    catch(e){checks.push({n:'Se reproduce',ok:false,v:'el navegador no lo reprodujo'});}
  }catch(e){checks.push({n:'Se puede abrir y leer',ok:false,v:e.message});}
  URL.revokeObjectURL(url);
  checks.push({n:'Formato',ok:true,v:ext.toUpperCase()+(ext==='webm'?' (tu navegador no graba MP4)':'')});
  return checks;
}

/* ============================================================
   PIPELINE · etapas visibles
   ============================================================ */
const STAGES=[
  ['analyze','Analizar tema, público y plataforma'],['research','Investigar datos actuales'],['script','Crear guion original'],
  ['duration','Calcular duración'],['storyboard','Storyboard de escenas'],['clips','Clips de vídeo con IA'],
  ['images','Imágenes de escena'],['voice','Narración'],['subs','Subtítulos sincronizados'],['music','Música y efectos'],
  ['render','Montar y exportar'],['verify','Verificar el archivo'],['preview','Vista previa'],['download','Descarga del vídeo']
];
const ST_LBL={pending:'Pendiente',run:'Procesando',done:'Terminado',err:'Error',skip:'No disponible',warn:'Revisar'};
function resetPipe(){S.pipe={};STAGES.forEach(([id])=>S.pipe[id]={s:'pending',n:'',pct:null});renderPipe();}
function setStage(id,s,n,pct){S.pipe[id]={s,n:n||'',pct:pct==null?null:pct};renderPipe();}
function pipeHTML(){
  return STAGES.map(([id,name])=>{
    const x=S.pipe[id]||{s:'pending',n:''},cls={pending:'',run:'s-run',done:'s-done',err:'s-err',skip:'s-skip',warn:'s-warn'}[x.s];
    const pc={done:'ok',run:'run',err:'err',skip:'skip',warn:'warn',pending:''}[x.s];
    return`<div class="step ${cls}"><i class="ic"></i><div><div class="nm">${esc(name)}</div>${x.n?`<div class="nt">${esc(x.n)}</div>`:''}${x.pct!=null?`<div class="bar"><i style="width:${x.pct}%"></i></div>`:''}</div><span class="pill ${pc}">${ST_LBL[x.s]}</span></div>`;
  }).join('');
}
function renderPipe(){
  const h=pipeHTML();$('#homePipe').innerHTML=h;$('#createPipe').innerHTML=h;
  $('#homePipeWrap').hidden=!(S.busy||S.rendering);renderTop();
}
function voiceStatus(p){
  if(p.narrator==='sin voz')return{s:'skip',n:'Este proyecto va sin narración. Los subtítulos cuentan la historia.'};
  if(MEDIA.voice)return{s:'done',n:'Usas tu pista de narración subida: «'+MEDIA.voiceName+'». Se incluye en el vídeo.'};
  const v=pickVoice(p.language,p.narrator);
  if(v)return{s:'warn',n:'Voz del dispositivo ('+v.name+') solo en la vista previa. El navegador no permite grabarla dentro del archivo. Sube tu propia narración para incluirla.'};
  return{s:'warn',n:'Este dispositivo no tiene voz instalada para '+LANGN[p.language]+'. Sube tu propia narración o instala una voz.'};
}
async function runPipeline(p,{autoRender=false}={}){
  if(S.busy||S.rendering){toast('Ya hay una tarea en curso.');return;}
  if(!p.topic.trim()){toast('Escribe el tema del vídeo.');return;}
  S.busy=true;resetPipe();S.result=null;showResult();
  try{
    await engine.ensure().catch(e=>logError('audio',e));
    setStage('analyze','run');await sleep(150);
    const plat=p.aspect==='9:16'?'Vertical (Shorts / Reels)':p.aspect==='16:9'?'Horizontal (YouTube)':'Cuadrado';
    setStage('analyze','done',`${plat} · ${p.seconds} s · ${LANGN[p.language]} · público: ${p.audience}`);
    setStage('research','skip','Sin búsqueda web en este entorno. Los datos salen del conocimiento del modelo de IA y quedan marcados para verificar.');
    setStage('script','run',claudeOK()?aiName()+' está escribiendo el guion…':'Plantilla local (sin IA)');
    const res=await generateScript(p);applyScript(p,res);
    setStage('script',res.source==='ai'?'done':'warn',res.source==='ai'?'Guion escrito por '+aiName()+'. Revisa los datos antes de publicar.':'Plantilla local. Sustituye los textos entre [corchetes] por datos reales.');
    const tot=totalDur(p),diff=Math.abs(tot-p.seconds)/p.seconds;
    setStage('duration',diff>0.25?'warn':'done',`${tot.toFixed(1)} s estimados · objetivo ${p.seconds} s`+(diff>0.25?'. Ajusta la duración de las escenas.':''));
    setStage('storyboard','done',`${p.scenes.length} escenas con tiempos y texto en pantalla. Transición: fundido con deslizamiento.`);
    setStage('clips','skip','Este entorno no tiene generación de vídeo con IA. Se usan escenas animadas locales, no clips de IA.');
    const nImg=p.scenes.filter(s=>MEDIA.img[s.id]).length;
    setStage('images','done',nImg?`${nImg} imagen(es) tuyas. El resto son fondos animados generados en tu dispositivo.`:'Fondos animados generados en tu dispositivo (no son imágenes de IA). Puedes adjuntar tus fotos en cada escena.');
    const vs=voiceStatus(p);setStage('voice',vs.s,vs.n);
    setStage('subs','done','Subtítulos incrustados, repartidos por la duración de cada escena (sincronización estimada).');
    setStage('music','done',p.music===false?'Música desactivada.':'Música generativa «'+({energetic:'enérgica',calm:'calmada',industrial:'industrial',bright:'luminosa'}[p.mood])+'» y efectos de transición.');
    p.resources=[{k:'Guion',v:res.source==='ai'?aiName():'Plantilla local'},{k:'Música',v:'Generada en el dispositivo ('+p.mood+')'},{k:'Imágenes',v:nImg?nImg+' del usuario':'Fondos procedurales'}];
    saveP(p);renderAll();player.t=0;player.still();
  }catch(e){logError('producción',e);toast('Error: '+(e.message||e));const cur=Object.keys(S.pipe).find(k=>S.pipe[k].s==='run');if(cur)setStage(cur,'err',e.message||String(e));S.busy=false;renderPipe();return;}
  S.busy=false;renderPipe();
  if(autoRender)await renderVideo(p);
}
async function renderVideo(p){
  if(S.rendering||S.busy)return;
  if(!p.scenes.length){toast('Genera primero el guion y las escenas.');return;}
  if(!canRecord()){toast('Este navegador no puede grabar vídeo.');return;}
  S.rendering=true;S.abort=false;S.result=null;showResult();
  ['render','verify','preview','download'].forEach(k=>setStage(k,'pending'));
  $('#renderBtn').disabled=true;$('#cancelBtn').hidden=false;$('#renderBar').hidden=false;renderTop();
  try{
    setStage('render','run','Grabando en tiempo real. Mantén la pantalla encendida y esta app en primer plano.',0);
    const out=await recordVideo(p,pct=>{setStage('render','run','Grabando en tiempo real. Mantén la pantalla encendida y esta app en primer plano.',pct);$('#renderBar i').style.width=pct+'%';});
    setStage('render','done',`${fmtSize(out.blob.size)} · ${out.ext.toUpperCase()}`+(out.hidden?'. La app pasó a segundo plano durante la grabación: puede haber fotogramas congelados.':''));
    setStage('verify','run','Abriendo el archivo para comprobarlo…');
    const checks=await verifyVideo(out.blob,p,out.ext),bad=checks.filter(c=>!c.ok);
    S.result={blob:out.blob,url:URL.createObjectURL(out.blob),ext:out.ext,mime:out.mime,checks,name:`jarvis-${slug(p.title||p.topic)}.${out.ext}`,hidden:out.hidden};
    setStage('verify',bad.length?'err':'done',bad.length?`${bad.length} comprobación(es) fallaron.`:`${checks.length} comprobaciones superadas.`);
    if(bad.length){setStage('preview','warn','Puedes ver el resultado, pero no se ofrece la descarga hasta que pase la verificación.');setStage('download','err','Bloqueada: el archivo no superó la verificación.');}
    else{setStage('preview','done','Reproduce el vídeo grabado en la sección Exportar.');setStage('download','pending','Pulsa «Descargar vídeo». El navegador te pedirá confirmación.');
      p.videos.unshift({name:S.result.name,size:out.blob.size,dur:+totalDur(p).toFixed(1),format:out.ext,res:dims(p).W+'×'+dims(p).H,date:Date.now()});p.videos=p.videos.slice(0,12);saveP(p);}
  }catch(e){
    if(e.cancelled){setStage('render','err','Cancelado por ti.');}
    else{logError('exportación',e);setStage('render','err',e.message||String(e));toast('No se pudo grabar: '+(e.message||e));}
  }
  S.rendering=false;player.pause();player.t=0;player.still();
  $('#renderBtn').disabled=false;$('#cancelBtn').hidden=true;$('#renderBar').hidden=true;$('#renderBar i').style.width='0';
  showResult();renderAll();
}
function showResult(){
  const r=S.result,vb=$('#verifyBox'),rb=$('#resultBox');
  if(!r){vb.hidden=true;rb.hidden=true;$('#outVideo').removeAttribute('src');return;}
  const bad=r.checks.filter(c=>!c.ok);
  vb.hidden=false;
  vb.innerHTML='<div class="pipe">'+r.checks.map(c=>`<div class="step ${c.ok?'s-done':'s-err'}"><i class="ic"></i><div><div class="nm">${esc(c.n)}</div><div class="nt">${esc(c.v)}</div></div><span class="pill ${c.ok?'ok':'err'}">${c.ok?'Correcto':'Falló'}</span></div>`).join('')+'</div>'+
    (r.hidden?'<div class="note" style="margin-top:10px">La app pasó a segundo plano durante la grabación. Si ves fotogramas congelados, vuelve a renderizar sin cambiar de app.</div>':'');
  rb.hidden=false;const v=$('#outVideo');if(v.src!==r.url)v.src=r.url;
  $('#dlBtn').hidden=bad.length>0;
}
async function downloadVideo(){
  const r=S.result;if(!r)return;
  if(!CAP.downloads){toast('Las descargas no están disponibles en este visor. Mantén pulsado el vídeo para guardarlo.');return;}
  try{await CAP.downloads.save({filename:r.name,data:r.blob});setStage('download','done','Guardado: '+r.name);toast('Vídeo guardado.');}
  catch(e){if(e.code==='declined')toast('Descarga cancelada.');else{logError('descarga',e);toast('No se pudo guardar: '+(e.message||e.code));}}
}

/* ============================================================
   CHAT · órdenes en lenguaje natural
   ============================================================ */
function parseCommand(raw){
  const text=raw.replace(/^\s*(jarvis|yarvis)[,:\s]+/i,'').trim(),lc=text.toLowerCase();
  const vid=/(v[ií]deo|video|short|shorts|reel|reels)/.test(lc);
  if(/(analiz|revis|mejor)/.test(lc)&&vid&&/(este|mi|ese|el)\b/.test(lc)&&!/(crea|haz|genera)/.test(lc))return{intent:'analyze'};
  if(/\b(crea|crear|haz|hacer|genera|generar|prepara|preparar|monta|montar|produce)\b/.test(lc)&&vid){
    const o={};
    const m=lc.match(/(\d+(?:[.,]\d+)?)\s*(segundos|segs?|s\b|minutos?|min\b)/);
    if(m){let v=parseFloat(m[1].replace(',','.'));if(/^min/.test(m[2]))v*=60;o.seconds=clamp(Math.round(v/5)*5,10,120);}
    if(/(horizontal|16:9|apaisado)/.test(lc))o.aspect='16:9';else if(/(cuadrad|1:1)/.test(lc))o.aspect='1:1';else if(/(vertical|9:16|short|reel|tiktok)/.test(lc))o.aspect='9:16';
    o.language=/portugu[eé]s|brasil/.test(lc)?'pt':/ingl[eé]s|english/.test(lc)?'en':'es';
    o.profile=/(minecraft|gta|fortnite|videojuego|gaming|gamer|juego)/.test(lc)?'gaming':/(asmr|relajante|susurr)/.test(lc)?'asmr':/(coche|auto\b|automóvil|restaur|motor|veh[ií]culo)/.test(lc)?'autos':/(educativ|ense[ñn]|aprender|ciencia|historia)/.test(lc)?'edu':null;
    o.subs=!/sin subt[ií]tulos/.test(lc);o.music=!/sin m[uú]sica/.test(lc);o.voice=!/sin (voz|narraci[oó]n)/.test(lc);
    let tp=text.match(/\b(?:sobre|acerca de|about|sobre o|sobre a)\s+(.+?)(?=,|\s+en\s+(?:español|portugu|ingl)|\s+con\s+(?:voz|narr|subt|m[uú]s)|\s+para\s+(?:mi|youtube|el canal|shorts|reels)|\s+formato|\.|$)/i);
    if(!tp)tp=text.match(/\bv[ií]deos?\s+(?:vertical\s+|horizontal\s+|educativo\s+|asmr\s+|relajante\s+)?de\s+(.+?)(?=,|\.|\s+en\s+(?:español|portugu)|\s+para\s+|$)/i);
    o.topic=tp?tp[1].trim().replace(/[.,;]+$/,''):'';
    return{intent:'create',params:o};
  }
  return{intent:'chat',text};
}
function addMsg(role,text,o={}){const m=Object.assign({role,text,id:uid()},o);S.chat.push(m);renderChat();return m;}
function renderChat(){
  const el=$('#chatLog');el.innerHTML='';
  S.chat.slice(-24).forEach(m=>{
    const d=document.createElement('div');d.className='msg '+m.role;const p=document.createElement('p');p.textContent=m.text;d.appendChild(p);
    if(m.plan){const ul=document.createElement('ul');m.plan.forEach(x=>{const li=document.createElement('li');li.textContent=x;ul.appendChild(li);});d.appendChild(ul);}
    if(m.actions){const r=document.createElement('div');r.className='row';m.actions.forEach(a=>{const b=document.createElement('button');b.className='btn sm';b.textContent=a.label;b.onclick=a.fn;r.appendChild(b);});d.appendChild(r);}
    el.appendChild(d);
  });
}
async function onCommand(raw){
  const text=raw.trim();if(!text)return;$('#cmd').value='';addMsg('user',text);
  setTimeout(()=>{const l=$('#chatLog').lastElementChild;if(l)l.scrollIntoView({block:'nearest',behavior:'smooth'});},50);
  const mem=text.match(/^\s*(?:jarvis[,:\s]+)?(?:recuerda|recu[eé]rdame|acu[eé]rdate)(?:\s+que)?\s+(.+)/i);
  if(mem){S.settings.prefs.push(mem[1].trim());saveSettings();renderSettings();addMsg('jarvis','Anotado: «'+mem[1].trim()+'». Lo envío a la IA al escribir guiones. Puedes editarlo en Ajustes.');return;}
  const cmd=parseCommand(text);
  if(cmd.intent==='create'){
    if(S.busy||S.rendering){addMsg('jarvis','Ya estoy trabajando en un vídeo. Espera a que termine.');return;}
    const o=cmd.params,key=o.profile||'edu',pr=S.settings.profiles[key];
    const topic=o.topic||((o.profile&&o.profile!=='edu')?pr.topic:'');
    if(!topic){addMsg('jarvis','¿Sobre qué tema quieres el vídeo? Por ejemplo: «Jarvis, crea un Short de 30 segundos sobre los volcanes».');return;}
    const p=newProject(key,{topic:topic.charAt(0).toUpperCase()+topic.slice(1),language:o.language,seconds:o.seconds||pr.seconds,aspect:o.aspect||S.settings.defaultAspect,subs:o.subs,music:o.music,narrator:o.voice?pr.narrator==='sin voz'&&key!=='asmr'?'femenina':pr.narrator:'sin voz'});
    S.projects.unshift(p);S.cur=p;saveP(p);renderAll();
    const plan=[`Tema: ${p.topic}`,`${p.seconds} s · ${p.aspect} · ${LANGN[p.language]}`,`Perfil: ${pr.name} · narrador: ${p.narrator}`,`Subtítulos ${p.subs?'sí':'no'} · música ${p.music?'sí':'no'}`,claudeOK()?'Guion: '+aiName():'Guion: plantilla local',S.settings.autoRender?'Después grabo el vídeo y lo verifico':'Después revisas y pulsas Renderizar'];
    addMsg('jarvis','Entendido. Plan de trabajo:',{plan,actions:[{label:'Abrir editor',fn:()=>go('crear')}]});
    await runPipeline(p,{autoRender:S.settings.autoRender});
    if(S.result)addMsg('jarvis',S.result.checks.every(c=>c.ok)?'Vídeo grabado y verificado. Descárgalo desde el editor.':'El vídeo se grabó pero no pasó todas las comprobaciones. Revisa el editor.',{actions:[{label:'Ver vídeo',fn:()=>go('crear')}]});
    else addMsg('jarvis',S.settings.autoRender?'El guion y las escenas están listos. La grabación no se completó; revisa el editor.':'Guion y escenas listos. Revísalos en el editor y pulsa Renderizar.',{actions:[{label:'Abrir editor',fn:()=>go('crear')}]});
    return;
  }
  if(cmd.intent==='analyze'){
    addMsg('jarvis','Elige el vídeo que quieres analizar. Lo leo en tu teléfono y no se sube a ningún sitio salvo unos fotogramas si usas una IA.',{actions:[{label:'Elegir vídeo',fn:()=>$('#fAnalyze').click()}]});return;
  }
  // conversación general
  if(!claudeOK()){addMsg('jarvis','Para conversar libremente necesito una IA conectada (claves en .env), que ahora no está disponible. Sí puedo ejecutar órdenes de vídeo, por ejemplo: «crea un Short de 30 segundos sobre…».');return;}
  S.turns.push({role:'user',content:text});
  const rules=`Eres JARVIS, el asistente de una app que crea vídeos cortos. Responde en español, breve y claro (máximo 6 frases salvo que pidan más).
Capacidades reales: escribir guiones, traducir, organizar trabajos, ideas de vídeo, revisar textos. Proyecto activo: ${S.cur?`«${S.cur.topic||'sin tema'}» (${S.cur.scenes.length} escenas)`:'ninguno'}.
Limitaciones: no tienes búsqueda web ni generación de imágenes, voz o clips dentro de esta app. Si algo requiere eso, dilo y ofrece una alternativa. No inventes datos. Para crear un vídeo, el usuario puede escribir «crea un Short de 30 segundos sobre…».
${S.settings.prefs.length?'Preferencias del usuario: '+S.settings.prefs.join('; '):''}`;
  const m=addMsg('jarvis','Pensando…');
  try{
    const r=await CAP.sample([{role:'user',content:rules},...S.turns.slice(-10)],{cache:false,modelTier:'quick',onText:({text})=>{m.text=text;renderChat();}});
    m.text=r.text;S.turns.push({role:'assistant',content:r.text});renderChat();
  }catch(e){handleSampleError(e);logError('chat',e);m.text=e.text||'No pude responder ahora ('+(e.code||'error')+').';renderChat();}
}
function startDictation(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition,mic=$('#micBtn');
  if(!SR){toast('El dictado no está disponible aquí. Usa el micrófono del teclado.');return;}
  const r=new SR();r.lang={es:'es-ES',pt:'pt-BR',en:'en-US'}[(getP()&&getP().language)||'es'];r.interimResults=true;
  r.onresult=e=>{$('#cmd').value=[...e.results].map(x=>x[0].transcript).join(' ');};
  r.onerror=e=>{toast(e.error==='not-allowed'||e.error==='service-not-allowed'?'El micrófono está bloqueado en este visor. Escribe la orden o usa el micrófono del teclado.':'Error de dictado: '+e.error);};
  r.onend=()=>mic.classList.remove('on');
  try{r.start();mic.classList.add('on');}catch(e){toast('No se pudo iniciar el dictado.');}
}

/* ---------- análisis de un vídeo existente ---------- */
async function analyzeVideo(file){
  const m=addMsg('jarvis','Analizando «'+file.name+'»…');
  const url=URL.createObjectURL(file),v=document.createElement('video');v.muted=true;v.playsInline=true;v.preload='auto';v.src=url;
  try{
    await waitEvt(v,'loadedmetadata',10000);
    if(!isFinite(v.duration)){v.currentTime=1e7;await waitEvt(v,'timeupdate',4000).catch(()=>{});}
    const info={dur:v.duration,w:v.videoWidth,h:v.videoHeight,size:file.size},frames=[];
    const c=document.createElement('canvas'),k=Math.min(1,640/Math.max(info.w,info.h));c.width=Math.round(info.w*k);c.height=Math.round(info.h*k);
    for(const f of [0.04,0.3,0.55,0.85]){v.currentTime=Math.max(0,info.dur*f);await waitEvt(v,'seeked',5000);c.getContext('2d').drawImage(v,0,0,c.width,c.height);
      const b=await new Promise(r=>c.toBlob(r,'image/jpeg',0.8));if(b)frames.push(b);}
    const kbps=Math.round(info.size*8/info.dur/1000),local=[
      `Duración ${fmtT(info.dur)} · ${info.w}×${info.h} · ${(info.size/1e6).toFixed(1)} MB · ≈${kbps} kb/s`,
      info.h>info.w?'Formato vertical: correcto para Shorts y Reels.':'Formato horizontal: para Shorts o Reels conviene 9:16.',
      Math.min(info.w,info.h)>=720?'Resolución suficiente (720p o más).':'Resolución baja: 720p o más se ve mejor.',
      info.dur<=60?'Duración corta, buena para retención.':'Más de 60 s: comprueba el límite actual de la plataforma.'
    ];
    m.text='Datos técnicos del vídeo:';m.plan=local;renderChat();
    if(claudeOK()&&CAP.images&&frames.length){
      const m2=addMsg('jarvis',aiName()+' está mirando 4 fotogramas…');
      try{
        const r=await CAP.sample(`Eres un editor de vídeos cortos. Te paso 4 fotogramas (inicio, 30 %, 55 % y 85 %) de un vídeo de ${fmtT(info.dur)}, ${info.w}×${info.h}. Solo ves imágenes, no oyes el audio. Da en español un análisis breve: gancho inicial, legibilidad de textos, encuadre y ritmo visual, y 3 mejoras concretas. Di claramente lo que no puedes saber con solo fotogramas.`,{images:frames,cache:false,onText:({text})=>{m2.text=text;renderChat();}});
        m2.text=r.text;renderChat();
      }catch(e){handleSampleError(e);logError('análisis',e);m2.text=aiName()+' no pudo analizar los fotogramas ('+(e.code||'error')+'). Arriba tienes los datos técnicos.';renderChat();}
    }else addMsg('jarvis','Sin una IA con imágenes solo puedo darte los datos técnicos de arriba.');
  }catch(e){logError('análisis',e);m.text='No pude leer ese vídeo: '+e.message;renderChat();}
  URL.revokeObjectURL(url);
}

/* ============================================================
   UI · vistas
   ============================================================ */
const VIEWS=['inicio','crear','proyectos','ajustes'];
function go(v){if(!VIEWS.includes(v))v='inicio';S.view=v;try{if(location.hash!=='#'+v)location.hash=v;}catch(e){}
  VIEWS.forEach(x=>{$('#v-'+x).hidden=x!==v;});$$('.nav button').forEach(b=>b.classList.toggle('on',b.dataset.go===v));
  if(v==='crear'){renderCreate();player.still();} window.scrollTo(0,0);}
function renderTop(){
  const dot=$('#topDot'),t=$('#topTxt');
  if(S.rendering){dot.className='dot busy';t.textContent='Grabando vídeo…';}
  else if(S.busy){dot.className='dot busy';t.textContent='Trabajando…';}
  else{dot.className='dot on';t.textContent=claudeOK()?aiName()+' + modo local':'Modo local';}
}
function renderQuick(){
  const q=['Jarvis, crea un Short de 30 segundos sobre 10 curiosidades de Minecraft','Jarvis, haz un vídeo de restauración de coches','Jarvis, crea un vídeo educativo en portugués','Jarvis, crea un vídeo ASMR relajante para mi canal'];
  $('#quick').innerHTML=q.map(x=>`<button class="chip" data-q="${esc(x)}">${esc(x.replace('Jarvis, ',''))}</button>`).join('');
}
function projCard(p,{actions=true}={}){
  const pr=S.settings.profiles[p.profile]||{name:p.profile};
  return`<div class="item" data-id="${p.id}"><div style="min-width:0"><div class="t">${esc(p.title||p.topic||'Proyecto sin tema')}</div>
    <div class="small">${esc(p.channel)} · ${esc(pr.name)} · ${p.scenes.length} escenas · ${totalDur(p).toFixed(0)} s · ${p.aspect}</div>
    <div class="row" style="margin-top:6px"><span class="pill ${p.videos.length?'ok':''}">${p.videos.length?p.videos.length+' vídeo(s) grabado(s)':'Sin vídeo'}</span><span class="pill">${esc(p.publish&&p.publish.status||'No publicado')}</span></div></div>
    ${actions?`<div class="row" style="flex:none"><button class="btn sm" data-open="${p.id}">Abrir</button><button class="btn sm danger" data-del="${p.id}">Borrar</button></div>`:`<button class="btn sm" data-open="${p.id}">Abrir</button>`}</div>`;
}
function renderRecent(){
  const el=$('#recent');
  el.innerHTML=S.projects.length?`<div class="panel">${S.projects.slice(0,3).map(p=>projCard(p,{actions:false})).join('')}</div>`:'<div class="empty">Aún no hay proyectos. Escribe una orden arriba para crear el primero.</div>';
}
function renderProjects(){
  $('#projList').innerHTML=S.projects.length?S.projects.map(p=>projCard(p)).join(''):'<div class="empty">Sin proyectos todavía.</div>';
  const opts=Object.values(S.settings.profiles).map(x=>`<option value="${x.key}">${esc(x.name)}</option>`).join('');
  const keep=$('#newProfSel').value,keep2=$('#pfSel').value;
  $('#newProfSel').innerHTML=opts;$('#pfSel').innerHTML=opts;$('#f-profile').innerHTML=opts;
  if(keep)$('#newProfSel').value=keep;if(keep2)$('#pfSel').value=keep2;
  fillProfileForm();
  $('#storeInfo').textContent='Almacenamiento: '+S.storage+'. Los vídeos grabados no se guardan en la app: descárgalos. Las imágenes y audios que subes duran mientras la página esté abierta.';
}
function fillProfileForm(){
  const pr=S.settings.profiles[$('#pfSel').value||'gaming'];if(!pr)return;
  $('#pf-name').value=pr.name;$('#pf-audience').value=pr.audience;$('#pf-style').value=pr.style;$('#pf-narrator').value=pr.narrator;$('#pf-seconds').value=pr.seconds;$('#pf-mood').value=pr.mood;
  pr.pal.forEach((c,i)=>{$('#pf-c'+i).value=c;});
}
function renderCreate(){
  const p=getP();
  const sel=$('#projSel');sel.innerHTML=S.projects.length?S.projects.map(x=>`<option value="${x.id}">${esc((x.title||x.topic||'Sin tema').slice(0,48))} · ${esc(x.channel)}</option>`).join(''):'<option value="">Sin proyectos</option>';
  if(p)sel.value=p.id;
  const dis=!p;$$('#briefForm input,#briefForm select,#briefForm textarea,#genBtn,#renderBtn,#addScene').forEach(e=>e.disabled=dis);
  if(!p){$('#scenes').innerHTML='<div class="empty">Crea un proyecto con «Nuevo» o escribe una orden en Inicio.</div>';$('#genHint').textContent='';return;}
  $('#f-topic').value=p.topic;$('#f-channel').value=p.channel;$('#f-profile').value=p.profile;$('#f-audience').value=p.audience;$('#f-language').value=p.language;
  $('#f-style').value=p.style;$('#f-narrator').value=p.narrator;$('#f-seconds').value=p.seconds;$('#secLbl').textContent=p.seconds+' s';$('#f-res').value=p.res;$('#f-mood').value=p.mood;
  $('#f-subs').checked=p.subs!==false;$('#f-music').checked=p.music!==false;
  ['voice','music','sfx'].forEach(k=>{$('#mx-'+k).value=p.mix[k];});
  $$('#aspectSeg button').forEach(b=>b.classList.toggle('on',b.dataset.asp===p.aspect));
  $('#genBtn').textContent=p.scenes.length?'Volver a generar el guion':'Generar guion y escenas';
  $('#genHint').textContent=claudeOK()?(IS_APP?aiName()+' escribe el guion con tu clave de API. Cada guion consume crédito de ese proveedor.':'El guion lo escribe Claude con tu cuenta. No cuesta dinero; usa tu cuota de Claude.'):'Modo gratuito local: se crea una plantilla de guion que completas tú.';
  renderScenes();renderAudioInfo();renderExportInfo();renderSources();renderPublish();showResult();renderPipe();
}
const VIS_LBL={title:'Título',number:'Número',statement:'Frase',image:'Imagen'};
function renderScenes(){
  const p=getP();if(!p)return;
  $('#durLbl').textContent=p.scenes.length?`· ${totalDur(p).toFixed(1)} s en total`:'';
  if(!p.scenes.length){$('#scenes').innerHTML='<div class="empty">Genera el guion para ver las escenas.</div>';return;}
  const idx=timelineIdx(p,player.t);
  $('#scenes').innerHTML=p.scenes.map((s,i)=>`<div class="scene${i===idx?' cur':''}" data-i="${i}">
    <div class="scene-h"><span class="sn">Escena ${i+1}</span><span class="pill">${VIS_LBL[s.visual]||s.visual}</span><span class="sp"></span>
      <button class="mini" data-act="up" aria-label="Subir escena" ${i===0?'disabled':''}>↑</button><button class="mini" data-act="down" aria-label="Bajar escena" ${i===p.scenes.length-1?'disabled':''}>↓</button>
      <button class="mini" data-act="go" aria-label="Ver escena">Ver</button></div>
    <label>Texto en pantalla<input data-f="onscreen" value="${esc(s.onscreen)}"></label>
    <label>Narración y subtítulos<textarea data-f="narration" rows="3">${esc(s.narration)}</textarea></label>
    <div class="grid2"><label>Duración (s)<input data-f="seconds" type="number" min="1" max="30" step="0.5" value="${s.seconds}"></label>
      <label>Tipo de escena<select data-f="visual">${Object.entries(VIS_LBL).map(([k,v])=>`<option value="${k}" ${s.visual===k?'selected':''}>${v}</option>`).join('')}</select></label>
      <label>Número (si es de lista)<input data-f="number" type="number" min="1" max="99" value="${s.number==null?'':s.number}"></label></div>
    <div class="row"><button class="btn sm" data-act="img">Elegir imagen</button><span class="imgname">${MEDIA.img[s.id]?esc(MEDIA.img[s.id].name):'Sin imagen: fondo animado'}</span></div>
    <div class="row"><button class="btn sm" data-act="regen">Regenerar escena</button><button class="btn sm danger" data-act="del">Quitar</button></div></div>`).join('');
}
function renderAudioInfo(){
  const p=getP();if(!p)return;
  $('#audioInfo').textContent=(MEDIA.voice?'Narración subida: '+MEDIA.voiceName+'. ':'Sin narración subida. ')+(MEDIA.music?'Música subida: '+MEDIA.musicName+'. ':'Música: generada en el dispositivo. ')+'Los volúmenes se aplican en la vista previa y en la grabación.';
}
function renderExportInfo(){
  const p=getP();if(!p)return;const mime=pickMime(),d=dims(p);
  const ok=canRecord();
  $('#expInfo').innerHTML=ok?`El vídeo se graba en tiempo real en este dispositivo: tarda lo mismo que dura (${totalDur(p).toFixed(0)} s). Salida ${d.W}×${d.H} en ${mime.includes('mp4')?'MP4':'WebM (tu navegador no graba MP4)'}. Mantén la pantalla encendida. La voz del dispositivo solo suena en la vista previa; para llevar voz al archivo sube tu narración.`:'Este navegador no puede grabar el vídeo (falta MediaRecorder o captureStream). Prueba con Chrome para Android.';
  $('#renderBtn').hidden=!ok;
}
function renderSources(){
  const p=getP();if(!p)return;
  const v=(p.verify||[]);
  $('#srcBox').innerHTML=`<div class="note info">JARVIS no tiene búsqueda web en este entorno. Los datos del guion vienen del conocimiento de la IA y no están verificados.</div>
   ${v.length?`<div><h3>Comprueba antes de publicar</h3><ul style="margin:8px 0 0;padding-left:18px;color:var(--mut)">${v.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`:'<div class="small">Cuando haya un guion verás aquí las afirmaciones que conviene verificar.</div>'}
   <div><h3>Fuentes guardadas</h3><div class="small" id="srcList">${(p.sources||[]).map(s=>esc(s.url?s.url+' · ':'')+esc(s.text||'')).join('<br>')||'Ninguna'}</div></div>
   <div class="row"><input id="srcIn" placeholder="https://… fuente que has verificado" style="flex:1"><button class="btn sm" id="srcAdd">Añadir</button></div>`;
}
function pubText(p){return`${p.title||p.topic}\n\n${p.description||''}\n\n${(p.tags||[]).map(t=>'#'+t.replace(/\s+/g,'')).join(' ')}`.trim();}
function renderPublish(){
  const p=getP();if(!p)return;
  $('#pubBox').innerHTML=`<div class="row"><span class="pill warn">${esc(p.publish.status)}</span><span class="small">Nada se publica sin tu aprobación.</span></div>
   <label>Título<input id="pb-title" value="${esc(p.title||'')}"></label>
   <label>Descripción<textarea id="pb-desc" rows="4">${esc(p.description||'')}</textarea></label>
   <label>Etiquetas (separadas por comas)<input id="pb-tags" value="${esc((p.tags||[]).join(', '))}"></label>
   <div class="row"><button class="btn sm" id="pbCopy">Copiar texto</button><button class="btn sm" id="pbThumb">Guardar miniatura</button><button class="btn sm" id="pbPack">Guardar paquete</button></div>
   <div class="note info">La publicación automática no está disponible: este entorno no tiene un conector de YouTube conectado. Descarga el vídeo y sube el texto y la miniatura a mano. JARVIS no marcará nada como publicado sin confirmación de la plataforma.</div>`;
}
async function saveFile(name,data){
  if(!CAP.downloads){toast('Las descargas no están disponibles en este visor.');return false;}
  try{await CAP.downloads.save({filename:name,data});toast('Guardado: '+name);return true;}
  catch(e){if(e.code!=='declined'){logError('descarga',e);toast('No se pudo guardar: '+(e.message||e.code));}return false;}
}
async function makeThumb(p){
  const q=Object.assign({},p,{aspect:'16:9',res:720,subs:false,scenes:[Object.assign({},p.scenes[0]||{},{visual:'title',onscreen:(p.title||p.topic||'').slice(0,60),seconds:3,seed:2,id:'thumb'})]});
  const c=document.createElement('canvas');c.width=1280;c.height=720;
  try{await document.fonts.load('700 40px "Outfit"');}catch(e){}
  renderFrame(c.getContext('2d'),1280,720,1.2,q,{noSubs:true,noProgress:true});
  return await new Promise(r=>c.toBlob(r,'image/png'));
}
function renderErrors(){
  const el=$('#errBox');if(!el)return;
  el.innerHTML=ErrLog.length?ErrLog.slice(0,10).map(e=>`<div class="item"><div style="min-width:0"><div class="t">${esc(e.area)}</div><div class="small">${esc(e.msg)}</div></div><span class="small mono">${new Date(e.t).toLocaleTimeString()}</span></div>`).join(''):'<div class="small">Sin errores en esta sesión.</div>';
}
function resRows(){
  const mime=pickMime(),voices=('speechSynthesis' in window)?speechSynthesis.getVoices():[];
  const vl=voices.filter(v=>/^(es|pt|en)/i.test(v.lang)).length;
  const SR=!!(window.SpeechRecognition||window.webkitSpeechRecognition);
  return[
    ...aiRows(),
    ['Video Studio / clips de IA','no','No integrado. Las escenas son animaciones locales, no clips de IA.'],
    ['Generación de imágenes con IA','no','No integrada. Usa fondos animados o tus fotos.'],
    ['Voz de IA en la nube','no','No integrada. Voz del dispositivo solo en la vista previa, o sube tu narración.'],
    ['Voces del dispositivo',vl?'ok':'warn',vl?vl+' voces en es/pt/en.':'Ninguna voz detectada.'],
    ['Grabación de vídeo',canRecord()?'ok':'no',canRecord()?'Formato: '+((mime||'').includes('mp4')?'MP4':'WebM')+'.':'MediaRecorder o captureStream no disponibles.'],
    ['Descargas',CAP.downloads?'ok':'no',CAP.downloads?(IS_APP?'Se guardan en tu carpeta de Descargas.':'Disponible con confirmación.'):'No disponible en este visor.'],
    ['Almacenamiento',CAP.db?'ok':'warn',S.storage],
    ['Dictado por voz',(window.SpeechRecognition||window.webkitSpeechRecognition)?'warn':'no',(SR?'El navegador lo ofrece, pero este visor puede bloquear el micrófono.':'No disponible.')],
    ['Pantalla siempre encendida',navigator.wakeLock?'ok':'warn',navigator.wakeLock?'Se pide durante la grabación.':'No disponible: mantén la pantalla encendida a mano.'],
    ['Créditos y saldo','no',(IS_APP?'JARVIS no consulta tu saldo. Las llamadas a la IA se cobran en la cuenta de cada proveedor; sin claves no se gasta nada.':'Este entorno no expone créditos. Nada de lo que hace JARVIS gasta dinero.')]
  ];
}
function renderResources(){
  const rows=resRows(),pill={ok:'ok',warn:'warn',no:'skip'},lbl={ok:'Sí',warn:'Parcial',no:'No'};
  $('#resFull').innerHTML=rows.map(r=>`<div class="res-row"><span>${esc(r[0])}</span><span class="pill ${pill[r[1]]}">${lbl[r[1]]}</span><span class="nt">${esc(r[2])}</span></div>`).join('');
  $('#resMini').innerHTML=rows.filter(r=>/^(Servidor local|Claude \(|ChatGPT|Grok|Video Studio|Voces del dispositivo|Grabación de vídeo|Almacenamiento)/.test(r[0])).map(r=>`<span class="pill ${pill[r[1]]}">${esc(r[0].split(' (')[0])}: ${lbl[r[1]]}</span>`).join('');
}
function renderSettings(){
  $$('#modeSeg button').forEach(b=>b.classList.toggle('on',(b.dataset.mode==='ia')===S.settings.useClaude));
  $('#modeInfo').textContent=S.settings.useClaude?(IS_APP?'La IA escribe guiones y conversa con tus claves de API: cada llamada cuesta según tu proveedor. Las escenas, música y grabación son siempre locales.':'Claude escribe guiones y conversa. Las escenas, música y grabación son siempre locales. No se contrata nada de pago.'):'Todo se hace en tu dispositivo con plantillas. Sin IA y sin gastar cuota.';
  $('#s-auto').checked=!!S.settings.autoRender;$('#s-aspect').value=S.settings.defaultAspect;$('#s-prefs').value=S.settings.prefs.join('\n');
  renderResources();renderErrors();renderAI();
}
function renderAll(){renderRecent();renderProjects();renderSettings();renderQuick();renderTop();if(S.view==='crear')renderCreate();}

/* ---------- eventos ---------- */
$('#sendBtn').onclick=()=>onCommand($('#cmd').value);
$('#cmd').addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();onCommand($('#cmd').value);}});
$('#micBtn').onclick=startDictation;
$('#quick').onclick=e=>{const b=e.target.closest('[data-q]');if(b){$('#cmd').value=b.dataset.q;$('#cmd').focus();}};
$$('.nav button').forEach(b=>b.onclick=()=>go(b.dataset.go));
window.addEventListener('hashchange',()=>{const v=location.hash.slice(1);if(VIEWS.includes(v)&&v!==S.view)go(v);});
document.addEventListener('click',e=>{
  const o=e.target.closest('[data-open]');if(o){const p=S.projects.find(x=>x.id===o.dataset.open);if(p){S.cur=p;player.t=0;go('crear');}return;}
  const d=e.target.closest('[data-del]');if(d){
    if(d.dataset.arm){const p=S.projects.find(x=>x.id===d.dataset.del);if(p){Store.remove(p);if(S.cur===p)S.cur=S.projects[0]||null;toast('Proyecto borrado.');renderAll();}}
    else{d.dataset.arm='1';d.textContent='Confirmar';setTimeout(()=>{if(d.isConnected){delete d.dataset.arm;d.textContent='Borrar';}},3500);}
    return;}
});
function createProject(key){
  const p=newProject(key||'edu');S.projects.unshift(p);S.cur=p;saveP(p);player.t=0;renderAll();go('crear');toast('Proyecto nuevo. Escribe el tema.');
}
$('#newProjBtn').onclick=()=>createProject($('#f-profile').value||'edu');
$('#newProj2').onclick=()=>createProject($('#newProfSel').value);
$('#projSel').onchange=e=>{const p=S.projects.find(x=>x.id===e.target.value);if(p){S.cur=p;player.t=0;S.result=null;renderCreate();player.still();}};

$('#briefForm').addEventListener('input',e=>{
  const p=getP(),f=e.target.dataset&&e.target.dataset.pf;if(!p||!f)return;
  let v=e.target.value;if(f==='seconds'||f==='res')v=+v;
  p[f]=v;if(f==='seconds')$('#secLbl').textContent=v+' s';
  if(f==='profile'){const pr=S.settings.profiles[v];if(pr){Object.assign(p,{style:pr.style,narrator:pr.narrator,mood:pr.mood,audience:pr.audience,channel:pr.name});renderCreate();toast('Perfil aplicado: '+pr.name);}}
  if(f==='res'||f==='mood')renderExportInfo();
  saveP(p);player.still();
});
$('#aspectSeg').onclick=e=>{const b=e.target.closest('[data-asp]');const p=getP();if(!b||!p)return;p.aspect=b.dataset.asp;saveP(p);renderCreate();player.still();};
$('#presets').onclick=e=>{
  const b=e.target.closest('[data-preset]');const p=getP();if(!b||!p)return;
  const k=b.dataset.preset;
  if(k==='shorts'){p.aspect='9:16';p.res=720;p.seconds=Math.min(p.seconds,60);}
  if(k==='reels'){p.aspect='9:16';p.res=720;p.seconds=Math.min(p.seconds,60);}
  if(k==='wide'){p.aspect='16:9';p.res=720;p.seconds=Math.max(p.seconds,30);}
  saveP(p);renderCreate();player.still();toast({shorts:'Preset YouTube Shorts: 9:16, 720p.',reels:'Preset Reels: 9:16, 720p. Deja libre la parte baja para la interfaz.',wide:'Preset horizontal: 16:9, 720p.'}[k]);
};
$('#f-subs').onchange=e=>{const p=getP();if(!p)return;p.subs=e.target.checked;saveP(p);player.still();};
$('#f-music').onchange=e=>{const p=getP();if(!p)return;p.music=e.target.checked;saveP(p);};
['voice','music','sfx'].forEach(k=>$('#mx-'+k).addEventListener('input',e=>{const p=getP();if(!p)return;p.mix[k]=+e.target.value;engine.applyMix();saveP(p);}));
$('#genBtn').onclick=async()=>{const p=getP();if(!p)return;if(p.scenes.length&&!$('#genBtn').dataset.arm){const b=$('#genBtn');b.dataset.arm='1';b.textContent='Confirmar: reemplaza el guion actual';setTimeout(()=>{delete b.dataset.arm;renderCreate();},3500);return;}
  delete $('#genBtn').dataset.arm;await runPipeline(p,{autoRender:false});};
$('#renderBtn').onclick=()=>{const p=getP();if(p)renderVideo(p);};
$('#cancelBtn').onclick=()=>{S.abort=true;player.pause();toast('Cancelando…');const rec=null;};
$('#dlBtn').onclick=downloadVideo;

$('#playBtn').onclick=()=>{if(player.playing)player.pause();else player.play({speak:true});};
$('#seek').addEventListener('input',e=>{const t=player.total()*e.target.value/1000;player.seek(t);});
$('#ttsOn').onchange=()=>{if(!$('#ttsOn').checked&&'speechSynthesis' in window)speechSynthesis.cancel();};

$('#scenes').addEventListener('input',e=>{
  const card=e.target.closest('.scene'),f=e.target.dataset.f,p=getP();if(!card||!f||!p)return;
  const s=p.scenes[+card.dataset.i];if(!s)return;
  if(f==='seconds')s.seconds=clamp(+e.target.value||1,1,30);else if(f==='number')s.number=e.target.value===''?null:+e.target.value;else s[f]=e.target.value;
  if(f==='narration'&&!card.dataset.manual){}
  saveP(p);$('#durLbl').textContent=`· ${totalDur(p).toFixed(1)} s en total`;player.still();
});
$('#scenes').addEventListener('change',e=>{if(e.target.dataset.f==='visual'||e.target.dataset.f==='number'){renderScenes();}});
$('#scenes').addEventListener('click',async e=>{
  const b=e.target.closest('[data-act]'),card=e.target.closest('.scene'),p=getP();if(!b||!card||!p)return;
  const i=+card.dataset.i,s=p.scenes[i],act=b.dataset.act;
  if(act==='up'&&i>0){[p.scenes[i-1],p.scenes[i]]=[p.scenes[i],p.scenes[i-1]];saveP(p);renderScenes();player.still();}
  else if(act==='down'&&i<p.scenes.length-1){[p.scenes[i+1],p.scenes[i]]=[p.scenes[i],p.scenes[i+1]];saveP(p);renderScenes();player.still();}
  else if(act==='go'){player.pause();player.t=timeline(p).starts[i]+0.8;player.still();renderScenes();cv.scrollIntoView({block:'center',behavior:'smooth'});}
  else if(act==='img'){S.imgFor=s.id;$('#fImg').click();}
  else if(act==='regen'){b.disabled=true;b.textContent='Regenerando…';await regenScene(p,i);renderScenes();player.still();}
  else if(act==='del'){if(b.dataset.arm){p.scenes.splice(i,1);saveP(p);renderScenes();player.still();}else{b.dataset.arm='1';b.textContent='Confirmar';setTimeout(()=>{if(b.isConnected){delete b.dataset.arm;b.textContent='Quitar';}},3000);}}
});
$('#addScene').onclick=()=>{const p=getP();if(!p)return;p.scenes.push(mkScene({narration:'',onscreen:'Nueva escena',visual:'statement',seconds:4},p.language));saveP(p);renderScenes();player.still();};
$('#fImg').onchange=async e=>{
  const f=e.target.files[0];e.target.value='';const p=getP();if(!f||!p||!S.imgFor)return;
  try{
    const bmp=await createImageBitmap(f);MEDIA.img[S.imgFor]={bmp,name:f.name};
    const s=p.scenes.find(x=>x.id===S.imgFor);if(s)s.visual='image';
    saveP(p);renderScenes();player.still();toast('Imagen añadida. Solo dura mientras la página esté abierta.');
  }catch(err){logError('imagen',err);toast('No se pudo leer la imagen.');}
};
$('#voiceFileBtn').onclick=()=>$('#fVoice').click();
$('#musicFileBtn').onclick=()=>$('#fMusic').click();
$('#fVoice').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;try{MEDIA.voice=await engine.decode(f);MEDIA.voiceName=f.name;renderAudioInfo();toast('Narración cargada ('+MEDIA.voice.duration.toFixed(1)+' s).');}catch(err){logError('audio',err);toast('No se pudo leer ese audio.');}};
$('#fMusic').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;try{MEDIA.music=await engine.decode(f);MEDIA.musicName=f.name;renderAudioInfo();toast('Música cargada.');}catch(err){logError('audio',err);toast('No se pudo leer ese audio.');}};
$('#clearAudioBtn').onclick=()=>{MEDIA.voice=null;MEDIA.music=null;MEDIA.voiceName=MEDIA.musicName='';renderAudioInfo();toast('Audios subidos quitados.');};
$('#fAnalyze').onchange=e=>{const f=e.target.files[0];e.target.value='';if(f)analyzeVideo(f);};

document.addEventListener('click',async e=>{
  if(e.target.id==='srcAdd'){const p=getP(),v=$('#srcIn').value.trim();if(!p||!v)return;p.sources.push({kind:'url',url:v,text:'añadida por el usuario'});saveP(p);renderSources();}
  if(e.target.id==='pbCopy'){const p=getP();if(!p)return;const t=pubText(p);try{await navigator.clipboard.writeText(t);toast('Texto copiado.');}catch(err){const ta=$('#pb-desc');ta.focus();ta.select();toast('Selecciona y copia el texto a mano.');}}
  if(e.target.id==='pbThumb'){const p=getP();if(!p)return;const b=await makeThumb(p);if(b)saveFile(`miniatura-${slug(p.title||p.topic)}.png`,b);}
  if(e.target.id==='pbPack'){const p=getP();if(!p)return;saveFile(`paquete-${slug(p.title||p.topic)}.json`,JSON.stringify({title:p.title,description:p.description,tags:p.tags,status:p.publish.status,verify:p.verify,sources:p.sources,scenes:p.scenes.map(s=>({onscreen:s.onscreen,narration:s.narration,seconds:s.seconds}))},null,2));}
});
document.addEventListener('input',e=>{
  const p=getP();if(!p)return;
  if(e.target.id==='pb-title'){p.title=e.target.value;saveP(p);}
  if(e.target.id==='pb-desc'){p.description=e.target.value;saveP(p);}
  if(e.target.id==='pb-tags'){p.tags=e.target.value.split(',').map(x=>x.trim()).filter(Boolean);saveP(p);}
});
/* proyectos */
$('#pfSel').onchange=fillProfileForm;
$('#pfSave').onclick=()=>{const k=$('#pfSel').value,pr=S.settings.profiles[k];if(!pr)return;
  Object.assign(pr,{name:$('#pf-name').value||pr.name,audience:$('#pf-audience').value,style:$('#pf-style').value,narrator:$('#pf-narrator').value,seconds:clamp(+$('#pf-seconds').value||30,10,120),mood:$('#pf-mood').value,pal:[0,1,2,3].map(i=>$('#pf-c'+i).value)});
  saveSettings();renderAll();toast('Perfil guardado. Se aplica a los proyectos nuevos y cuando lo eliges en la ficha.');};
$('#pfReset').onclick=()=>{const k=$('#pfSel').value;S.settings.profiles[k]=clone(PROFILES0[k]||PROFILES0.edu);saveSettings();renderAll();toast('Perfil restaurado.');};
$('#expData').onclick=()=>saveFile('jarvis-datos.json',JSON.stringify({exportado:new Date().toISOString(),ajustes:S.settings,proyectos:S.projects},null,2));
$('#wipeBtn').onclick=()=>{const b=$('#wipeBtn');if(b.dataset.arm){S.projects.slice().forEach(p=>Store.remove(p));S.cur=null;S.result=null;delete b.dataset.arm;b.textContent='Borrar todos los proyectos';renderAll();toast('Proyectos borrados.');}else{b.dataset.arm='1';b.textContent='Confirmar: no se puede deshacer';setTimeout(()=>{delete b.dataset.arm;b.textContent='Borrar todos los proyectos';},3500);}};
/* ajustes */
$('#modeSeg').onclick=e=>{const b=e.target.closest('[data-mode]');if(!b)return;S.settings.useClaude=b.dataset.mode==='ia';saveSettings();renderSettings();renderTop();};
$('#s-auto').onchange=e=>{S.settings.autoRender=e.target.checked;saveSettings();};
$('#s-aspect').onchange=e=>{S.settings.defaultAspect=e.target.value;saveSettings();};
$('#prefsSave').onclick=()=>{S.settings.prefs=$('#s-prefs').value.split('\n').map(x=>x.trim()).filter(Boolean);saveSettings();toast('Preferencias guardadas.');};
$('#permBtn').onclick=async()=>{try{if(CAP.perm&&CAP.perm.manage)await CAP.perm.manage();else toast(IS_APP?'Toca el candado de la barra de direcciones de Chrome para gestionar micrófono y otros permisos.':'Gestiona los permisos desde el menú del artefacto, arriba a la derecha.');}catch(e){toast(IS_APP?'Abre los permisos del sitio desde el candado de Chrome.':'Abre el menú de permisos del artefacto.');}};
if('speechSynthesis' in window)speechSynthesis.onvoiceschanged=()=>renderResources();

/* ---------- arranque ---------- */
async function initCaps(){
  const C=window.claude;
  if(C&&C.use){
    const get=n=>Promise.resolve().then(()=>C.use(n)).catch(()=>null);
    const [sample,dl,db,perm]=await Promise.all([get('sample'),get('downloads'),get('db'),get('permissions')]);
    CAP.sample=sample;CAP.downloads=dl;CAP.db=db;CAP.perm=perm;
    if(sample&&sample.limits){try{const l=await sample.limits();CAP.images=!!(l&&l.images);}catch(e){}}
    if(db)await Store.attachCloud(db);
  }else if(IS_APP){await initApp();}
  CAP.ready=true;renderAll();
  if(S.cur&&!S.projects.includes(S.cur))S.cur=S.projects[0]||null;
}
Store.loadLocal();
S.cur=S.projects[0]||null;
resetPipe();renderAll();renderChat();
addMsg('jarvis','Soy JARVIS. Dime qué vídeo quieres y lo preparo: guion, escenas, subtítulos, música y grabación del archivo. Sin claves de IA todo es gratis y se hace en tu dispositivo. Con claves, cada llamada la cobra tu proveedor.');
const h=(location.hash||'').slice(1);go(VIEWS.includes(h)?h:'inicio');
player.still();
initCaps();
if(IS_APP&&'serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(e=>logError('sw',e));
window.__jarvis={AI,S,CAP,MEDIA,player,engine,runPipeline,renderVideo,onCommand,parseCommand,verifyVideo,getP};
})();
