/* JARVIS · service worker: guarda la app para abrirla más rápido y sin Internet.
   Nunca guarda llamadas a /api (tus órdenes y las respuestas de la IA no se almacenan aquí). */
const CACHE = 'jarvis-shell-v2';
const SHELL = [
  '/', '/index.html', '/app.js', '/manifest.webmanifest',
  '/fonts/fonts.css',
  '/fonts/Outfit-Regular.ttf', '/fonts/Outfit-Bold.ttf',
  '/fonts/InstrumentSans-Regular.ttf', '/fonts/InstrumentSans-Bold.ttf',
  '/fonts/IBMPlexMono-Regular.ttf', '/fonts/IBMPlexMono-Bold.ttf',
  '/icons/icon.svg', '/icons/icon-192.png', '/icons/icon-512.png', '/icons/maskable-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys()
    .then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;
  e.respondWith(
    fetch(req).then((r) => {
      if (r.ok) { const copy = r.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
      return r;
    }).catch(() => caches.match(req).then((m) => m || caches.match('/index.html')))
  );
});
