@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Falta Node.js 18 o superior. Descargalo en https://nodejs.org
  pause
  exit /b 1
)
if not exist .env (
  echo Primera vez: configura tus claves, todas son opcionales.
  node setup.js
)
start "" http://localhost:8787
node server.js
pause
