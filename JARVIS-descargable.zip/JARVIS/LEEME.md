# JARVIS · creador de vídeos cortos con IA opcional

JARVIS convierte una orden escrita en un vídeo corto: guion, escenas animadas, subtítulos, música y un archivo MP4 que se graba en tu propio dispositivo. La IA es opcional. Puedes conectar **Claude**, **ChatGPT** y **Grok** con tus propias claves de API, y sin claves todo funciona en modo gratuito local.

Esta carpeta es la aplicación completa. No hay que instalar nada más que Node.js.

---

## 1. Qué necesitas

- **Node.js 18 o superior** (https://nodejs.org). En Android se instala con Termux.
- **Chrome** (o Edge). Es el navegador con el que se probó la grabación de vídeo.
- Opcional: claves de API de los proveedores que quieras usar.

## 2. Arrancar

**Windows:** doble clic en `iniciar.bat`.

**macOS o Linux:** en una terminal, dentro de esta carpeta:

```
sh iniciar.sh
```

**Android (Termux):**

```
pkg update && pkg install nodejs unzip
unzip JARVIS-descargable.zip
cd JARVIS
sh iniciar.sh
```

La primera vez, JARVIS te pregunta por tus claves (todas opcionales; pulsa Enter para saltarte las que no tengas). Después abre **http://localhost:8787** en el navegador. Para parar el servidor, pulsa `Ctrl+C`.

Para repetir la configuración de claves en cualquier momento: `node setup.js`.

## 3. Instalarla como app

Con el servidor en marcha, abre `http://localhost:8787` en Chrome. Menú ⋮, y «Instalar aplicación» (o «Añadir a pantalla de inicio»). Se crea un icono que abre JARVIS a pantalla completa. La pantalla se guarda en el dispositivo y abre aunque no haya Internet ni servidor, pero sin servidor no hay IA ni datos nuevos de Ajustes.

Esto **no es un APK**. La primera visita necesita el servidor en marcha, y después hace falta para usar la IA. En Android, arranca Termux y ejecuta `sh iniciar.sh` antes de usar la IA.

## 4. Conectar ChatGPT, Claude y Grok

1. Consigue una clave de API en cada proveedor (todos cobran por uso):
   - Claude: https://console.anthropic.com
   - ChatGPT: https://platform.openai.com/api-keys
   - Grok: https://console.x.ai
2. Pégalas con `node setup.js` o escríbelas en un archivo `.env` (copia `.env.example`).
3. Reinicia JARVIS.
4. En **Ajustes → Conexión con IA**, pulsa «Cargar modelos» en cada proveedor y elige un modelo. Hasta que elijas modelo, el proveedor aparece como «Elige modelo».
5. Elige **Automático** o un proveedor concreto.

En **Automático**, JARVIS usa Claude, luego ChatGPT y luego Grok. Si uno falla por clave, saldo, límite de uso, modelo inexistente, error del proveedor o tiempo agotado, pasa al siguiente y te lo avisa. Si fallan todos, usa la plantilla local y te lo dice.

**Importante sobre costes**
- Las suscripciones de ChatGPT, Claude o Grok **no incluyen la API**. La API se factura aparte, por uso, en la cuenta del proveedor.
- JARVIS no consulta tu saldo. Cada guion, cada reescritura de escena, cada mensaje del chat y cada análisis de vídeo es una llamada de pago.
- `MAX_CALLS_PER_DAY` (por defecto 300) frena el gasto. En Ajustes → «Gratuito local» desactivas la IA por completo.

## 5. Seguridad

- Las claves viven **solo** en el archivo `.env` de tu equipo. El navegador nunca las recibe, y tampoco aparecen en los datos que exportas.
- El servidor escucha solo en `127.0.0.1` (este equipo). Rechaza peticiones con otro `Host` y de otros orígenes, para que una página web externa no pueda gastar tus llamadas.
- Para usar JARVIS desde otro dispositivo de tu red (por ejemplo, el móvil con el servidor en tu PC), pon en `.env`: `HOST=0.0.0.0` y `ACCESS_PIN=` con un PIN de 4 o más caracteres. Sin PIN, el servidor se niega a arrancar. Tras 5 PIN erróneos se bloquea 60 segundos.
- Por la red local la conexión es HTTP, no HTTPS. El navegador solo deja instalar la app y usar el micrófono desde `localhost`. En una red en la que no confíes, no abras JARVIS a la red.
- No compartas el archivo `.env`.

## 6. Cómo usarla

**Inicio.** Escribe una orden: «Jarvis, crea un Short de 30 segundos sobre 10 curiosidades de Minecraft». JARVIS entiende duración, formato, idioma, subtítulos, música y perfil de canal, te muestra el plan y empieza. Si «Renderizar automáticamente» está activado en Ajustes, graba también el vídeo.

**Crear vídeo.** Ficha del proyecto, guion y escenas, vista previa, editor de escenas (orden, duración, texto, narración, imagen propia), audio y subtítulos, grabación, descarga, fuentes y publicación.

**Proyectos.** Un proyecto por canal, con perfiles de Videojuegos, ASMR, Restauración de coches y Educación que puedes modificar. Exportar y borrar datos.

**Ajustes.** Modo de producción, formato por defecto, preferencias que JARVIS recuerda («Jarvis, recuerda que…»), recursos reales del dispositivo y registro de errores.

## 7. Qué hace de verdad y qué no

| Función | Estado |
|---|---|
| Guion con Claude, ChatGPT o Grok | Con clave. Sin clave: plantilla local |
| Escenas animadas, subtítulos, música generada | Locales, siempre disponibles |
| Grabación de MP4 con audio y verificación | Local, en tiempo real (un vídeo de 30 s tarda 30 s) |
| Descarga del archivo | Sí |
| Análisis de un vídeo existente | Datos técnicos siempre. Con IA con visión, también una valoración de 4 fotogramas (no escucha el audio) |
| Clips de vídeo generados por IA | **No.** Las escenas son animaciones locales, nunca se presentan como clips de IA |
| Imágenes generadas por IA | **No.** Fondos animados o tus propias fotos |
| Voz de IA en la nube | **No.** La voz del dispositivo suena en la vista previa, pero el navegador no la deja grabar dentro del archivo. Para llevar voz al vídeo, sube tu propia narración |
| Búsqueda web y verificación de datos | **No.** Los datos del guion salen del modelo y se marcan «para verificar» |
| Publicación en YouTube | **No.** Prepara título, descripción, etiquetas, miniatura y paquete. JARVIS no marca nada como publicado |
| Consultar créditos | **No** |

## 8. Cómo probar que funciona

1. Arranca JARVIS y abre `http://localhost:8787`.
2. En Inicio escribe: `Jarvis, crea un Short educativo de 10 segundos sobre los volcanes`. Sin claves se crea un guion de plantilla con textos entre [corchetes] para completar.
3. Abre **Crear vídeo**, revisa las escenas y pulsa **Renderizar vídeo**. Mantén la pantalla encendida y JARVIS en primer plano.
4. Al terminar verás seis comprobaciones: el archivo existe, se abre, la duración y la resolución son las esperadas, se reproduce y el formato.
5. Pulsa **Descargar vídeo**. Se guarda en tu carpeta de Descargas.

## 9. Errores conocidos y soluciones

| Síntoma | Solución |
|---|---|
| «No se encontró el servidor local» | Arranca JARVIS con `iniciar.bat` o `sh iniciar.sh` y entra por `http://localhost:8787` |
| «El puerto 8787 ya está en uso» | Cierra la otra copia o cambia `PORT` en `.env` (y abre esa dirección a mano, porque `iniciar.bat` abre siempre el 8787) |
| Claude, ChatGPT o Grok aparecen como «Sin clave» | Falta la clave en `.env`. Ejecuta `node setup.js` y reinicia |
| «Elige modelo» | En Ajustes pulsa «Cargar modelos» y elige uno |
| Error de modelo | El modelo ya no existe para tu cuenta. Carga la lista y elige otro |
| «Sin saldo o cuota» | Recarga la cuenta de API del proveedor |
| El vídeo sale con imagen congelada | JARVIS pasó a segundo plano durante la grabación. Vuelve a renderizar sin cambiar de app |
| El vídeo es WebM y no MP4 | Tu navegador no graba MP4. Usa Chrome |
| El dictado por voz no funciona | Necesita `localhost` o HTTPS y permiso de micrófono |
| Las imágenes y audios que subes desaparecen | Duran mientras la página esté abierta. Vuélvelos a subir |
| Los proyectos desaparecen | Se guardan en este navegador. Si borras los datos del sitio, se pierden. Usa «Exportar datos» como copia |

## 10. Qué contiene la carpeta

```
server.js            servidor local: sirve la app y llama a las IA con tus claves
setup.js             asistente para guardar las claves en .env
iniciar.bat / .sh    lanzadores
.env.example         plantilla de configuración
package.json
public/
  index.html         pantalla de la app
  app.js             lógica de la app
  sw.js              service worker (apertura rápida y sin conexión)
  manifest.webmanifest
  fonts/             fuentes incluidas (licencia OFL)
  icons/
```

## 11. Qué se ha probado

La conexión con las tres IA se probó contra **servidores simulados** que imitan el formato de Anthropic, OpenAI y xAI, no contra las APIs reales, porque las pruebas se hicieron sin claves reales. Se comprobó el enrutado de cada clave, los formatos de petición y respuesta, las imágenes, los errores principales (clave incorrecta, sin saldo, modelo inexistente, fallo del proveedor, respuesta vacía, proveedor inalcanzable y proveedor sin configurar), el respaldo entre proveedores, el límite diario, el PIN y las protecciones del servidor. La interfaz se probó en Chromium con pantalla de móvil, incluida la grabación, la verificación y la descarga de un MP4 real.

**No se probó** con las APIs reales de los tres proveedores, en un teléfono Android ni con Termux. Si un proveedor cambió su formato o sus nombres de modelo, JARVIS te mostrará el error de ese proveedor en Ajustes y en el registro de errores.
