#!/bin/sh
# Inicia JARVIS en Linux, macOS o Termux (Android).
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "Falta Node.js 18 o superior. En Termux: pkg install nodejs. En otros sistemas: https://nodejs.org"
  exit 1
fi
if [ ! -f .env ]; then
  echo "Primera vez: configura tus claves (todas son opcionales)."
  node setup.js
fi
exec node server.js
